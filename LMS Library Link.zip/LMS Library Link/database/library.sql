// ===============================
// Library Link Dashboard
// ===============================

// Check Session
async function checkSession() {

    const {
        data: { session },
        error
    } = await supabaseClient.auth.getSession();

    if (!session) {
        window.location.href = "login.html";
        return;
    }

    loadUser(session.user);
    loadDashboard();

}

checkSession();


// ===============================
// Load Logged-in User
// ===============================

function loadUser(user) {

    const studentName = document.getElementById("studentName");

    if (studentName) {

        studentName.textContent =
            user.user_metadata.fullname ||
            user.email;

    }

}


// ===============================
// Logout
// ===============================

async function logout() {

    await supabaseClient.auth.signOut();

    window.location.href = "login.html";

}


// ===============================
// Dashboard Statistics
// ===============================

async function loadDashboard() {

    loadBorrowedBooks();
    loadAvailableBooks();
    loadNotifications();

}


// ===============================
// Borrowed Books
// ===============================

async function loadBorrowedBooks() {

    const table = document.getElementById("borrowTable");

    if (!table) return;

    table.innerHTML = "";

    const {
        data,
        error
    } = await supabaseClient
        .from("borrow_records")
        .select(`
            borrow_date,
            due_date,
            status,
            books(title)
        `);

    if (error) {

        console.log(error);

        table.innerHTML = `
        <tr>
            <td colspan="4">
                Unable to load books.
            </td>
        </tr>`;

        return;

    }

    if (data.length === 0) {

        table.innerHTML = `
        <tr>
            <td colspan="4">
                No borrowed books.
            </td>
        </tr>`;

        document.getElementById("borrowedCount").innerHTML = 0;

        return;

    }

    document.getElementById("borrowedCount").innerHTML = data.length;

    data.forEach(book => {

        table.innerHTML += `

        <tr>

            <td>${book.books.title}</td>

            <td>${book.borrow_date}</td>

            <td>${book.due_date}</td>

            <td>${book.status}</td>

        </tr>

        `;

    });

}


// ===============================
// Notifications
// ===============================

async function loadNotifications() {

    const notificationCount =
        document.getElementById("notificationCount");

    const {
        data,
        error
    } = await supabaseClient
        .from("notifications")
        .select("*");

    if (error) {

        console.log(error);
        return;

    }

    notificationCount.innerHTML = data.length;

}


// ===============================
// Available Books
// ===============================

async function loadAvailableBooks() {

    const {
        data,
        error
    } = await supabaseClient
        .from("books")
        .select("*")
        .limit(4);

    if (error) {

        console.log(error);
        return;

    }

    console.log(data);

}


// ===============================
// Due Books
// ===============================

async function loadDueBooks() {

    const dueCount =
        document.getElementById("dueCount");

    const {
        data,
        error
    } = await supabaseClient
        .from("borrow_records")
        .select("*")
        .eq("status", "Borrowed");

    if (error) {

        console.log(error);
        return;

    }

    dueCount.innerHTML = data.length;

}

loadDueBooks();


// ===============================
// Reservation Count
// ===============================

async function loadReservations() {

    const reserve =
        document.getElementById("reserveCount");

    const {
        data,
        error
    } = await supabaseClient
        .from("reservations")
        .select("*");

    if (error) {

        console.log(error);
        return;

    }

    reserve.innerHTML = data.length;

}

loadReservations();


// ===============================
// Greeting
// ===============================

const hour = new Date().getHours();

const title = document.querySelector("header h1");

if (title) {

    if (hour < 12) {

        title.innerHTML = "Good Morning!";

    }

    else if (hour < 18) {

        title.innerHTML = "Good Afternoon!";

    }

    else {

        title.innerHTML = "Good Evening!";

    }

}

// NOTE: SQL seed data was moved to `database/seed_notifications.sql`.