# Database Folder

This folder holds database-related files for the Library Link project.

## Files

- `library.sql`
  - This file previously contained SQL seed statements embedded in application logic.
  - The SQL insert statements were removed and moved to a dedicated seed file.
  - Note: the current content remains as application JavaScript/logic and is not a pure SQL schema file.

- `seed_notifications.sql`
  - Contains seed data for the `notifications` table.
  - Replace `YOUR_USER_ID` with actual user IDs before importing.

## Usage

To load the notification seed data into your database, run the appropriate SQL import command for your database. Example for PostgreSQL:

```bash
psql -d your_database_name -f database/seed_notifications.sql
```

If you want to fully separate application logic from database files, consider moving `database/library.sql` to the `js/` folder and renaming it to `dashboard.js` or similar.
