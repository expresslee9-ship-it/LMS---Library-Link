-- Seed notifications for Library Link
-- Replace 'YOUR_USER_ID' with real user IDs when seeding

INSERT INTO notifications (user_id, title, message) VALUES
('YOUR_USER_ID', 'Welcome!', 'Welcome to Library Link.'),
('YOUR_USER_ID', 'Borrow Reminder', 'Please return your borrowed book before its due date.'),
('YOUR_USER_ID', 'Library Announcement', 'New books have been added to the collection.');
