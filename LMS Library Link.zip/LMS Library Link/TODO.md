# TODO

## Goal: Fix all errors on dashboard + correctness + performance

### Step 1: Repo understanding (done)
- [x] Read `html/dashboard.html` to confirm element IDs.
- [x] Read `js/dashboard.js` to identify current logic.
- [x] Read shared config helpers in `js/app.js`.

### Step 2: Fix runtime errors in `js/dashboard.js`
- [x] Replace buggy `escapeHtml()` implementation.
- [x] Add guard to prevent crashes when `supabaseClient` is missing.

### Step 3: Fix missing functionality
- [x] Wire “Borrow” buttons in the dashboard “Recently Added Books” section via event delegation.

### Step 4: Performance/correctness improvements
- [ ] Ensure borrowed due/reservation/notification queries select minimal columns.
- [ ] Verify `borrow_records` join `books(title)` matches schema.

### Step 5: Test
- [ ] Open `dashboard.html` and verify no console errors.
- [ ] Verify counts show correct user-scoped values.
- [ ] Verify borrowed table renders.
- [ ] Verify “Borrow” buttons redirect/work as expected.

