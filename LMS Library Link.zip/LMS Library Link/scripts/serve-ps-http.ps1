$root = "C:\Users\admin\Downloads\LMS Library Link"
$listener = New-Object System.Net.HttpListener
$prefix = "http://localhost:3000/"
$listener.Prefixes.Add($prefix)
$listener.Start()
Write-Output "Serving project root $root on http://localhost:3000/ - press Ctrl+C to stop"
while ($listener.IsListening) {
  $context = $listener.GetContext()
  try {
    $req = $context.Request
    $urlPath = $req.Url.LocalPath.TrimStart('/')
    if ([string]::IsNullOrEmpty($urlPath)) { $urlPath = 'html/index.html' }
    $file = Join-Path $root $urlPath
    if (Test-Path $file) {
      $bytes = [System.IO.File]::ReadAllBytes($file)
      $context.Response.ContentLength64 = $bytes.Length
      switch ([System.IO.Path]::GetExtension($file).ToLower()) {
        '.html' { $context.Response.ContentType = 'text/html' }
        '.htm'  { $context.Response.ContentType = 'text/html' }
        '.css'  { $context.Response.ContentType = 'text/css' }
        '.js'   { $context.Response.ContentType = 'application/javascript' }
        '.png'  { $context.Response.ContentType = 'image/png' }
        '.jpg'  { $context.Response.ContentType = 'image/jpeg' }
        '.jpeg' { $context.Response.ContentType = 'image/jpeg' }
        '.svg'  { $context.Response.ContentType = 'image/svg+xml' }
        '.json' { $context.Response.ContentType = 'application/json' }
        default { $context.Response.ContentType = 'application/octet-stream' }
      }
      $context.Response.OutputStream.Write($bytes,0,$bytes.Length)
    } else {
      $context.Response.StatusCode = 404
      $buf = [System.Text.Encoding]::UTF8.GetBytes('Not Found')
      $context.Response.OutputStream.Write($buf,0,$buf.Length)
    }
  } catch {
    Write-Output "Error serving request: $_"
  } finally {
    $context.Response.Close()
  }
}
$listener.Stop()
$listener.Close()
