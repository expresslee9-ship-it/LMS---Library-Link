async function loadBorrowedBooks() {

const {

data:{session}

}=await supabaseClient.auth.getSession();

const table=document.getElementById("returnTable");

table.innerHTML="";

const {data,error}=await supabaseClient

.from("borrow_records")

.select(`
id,
borrow_date,
due_date,
status,
books(title)
`)

.eq("user_id",session.user.id)

.eq("status","Borrowed");

if(error){

table.innerHTML="<tr><td colspan='4'>Unable to load.</td></tr>";

return;

}

if(data.length===0){

table.innerHTML="<tr><td colspan='4'>No borrowed books.</td></tr>";

return;

}

data.forEach(book=>{

table.innerHTML+=`

<tr>

<td>${book.books.title}</td>

<td>${book.borrow_date}</td>

<td>${book.due_date}</td>

<td>

<button onclick="returnBook(${book.id})">

Return

</button>

</td>

</tr>

`;

});

}

loadBorrowedBooks();



async function returnBook(id){

const {

error

}=await supabaseClient

.from("borrow_records")

.update({

status:"Returned",

return_date:new Date()

})

.eq("id",id);

if(error){

alert(error.message);

return;

}

alert("Book returned.");

location.reload();

}