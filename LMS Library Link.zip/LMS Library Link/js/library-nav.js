/* ===================== NAV / VIEWS ===================== */
function renderNavLinks(){
  const nav = document.getElementById('nav-links');
  if(!nav) return;
  nav.innerHTML = '';
  const links = currentUser
    ? (currentUser.role === 'Librarian'
        ? [['home','Home'],['managebooks','Manage Books'],['books','Books'],['notifications','Notifications'],['profile','My Profile']]
        : [['home','Home'],['notifications','Notifications'],['books','Books'],['history','History Logs'],['saved','Saved Books']])
    : [['home','Home'],['books','Books'],['contact','Contacts']];

  links.forEach(([key,label])=>{
    const a = document.createElement('a');
    a.textContent = label;
    a.dataset.nav = key;
    a.addEventListener('click', ()=>showView(key));
    nav.appendChild(a);
  });

  if(!currentUser){
    const login = document.createElement('a');
    login.textContent = 'Login';
    login.id = 'nav-login';
    login.addEventListener('click', ()=>showView('role'));
    nav.appendChild(login);
  }
}

function renderNav(){
  renderNavLinks();
  const slot = document.getElementById('nav-auth-slot');
  if(!slot) return;
  slot.innerHTML = '';
  const isLibrarianUser = currentUser && currentUser.role === 'Librarian';
  const homeGuest = document.getElementById('home-guest');
  const homeReader = document.getElementById('home-reader');
  const homeLibrarian = document.getElementById('home-librarian');
  if(homeGuest) homeGuest.style.display = currentUser ? 'none' : 'block';
  if(homeReader) homeReader.style.display = (currentUser && !isLibrarianUser) ? 'block' : 'none';
  if(homeLibrarian) homeLibrarian.style.display = isLibrarianUser ? 'block' : 'none';

  if(currentUser){
    const wrap = document.createElement('div');
    wrap.className = 'acct';
    wrap.innerHTML = `
      <div class="acct-btn" id="acct-btn">👤 ${currentUser.name.split(' ')[0]} ▾</div>
      <div class="acct-menu" id="acct-menu">
        ${currentUser.role === 'Librarian'
          ? `<div data-nav="profile">👤 My Profile</div>
             <div data-nav="managebooks">🗂 Manage Books</div>`
          : `<div data-nav="profile">👤 My Profile</div>
             <div data-nav="mybooks">My Books (${currentUser.borrowed.length})</div>
             <div data-nav="saved">Saved Books (${currentUser.saved.length})</div>`
        }
        <div id="acct-logout">Log Out</div>
      </div>`;
    slot.appendChild(wrap);

    const acctBtn = document.getElementById('acct-btn');
    const acctMenu = document.getElementById('acct-menu');
    if(acctBtn && acctMenu){
      acctBtn.addEventListener('click', (e)=>{
        e.stopPropagation();
        acctMenu.classList.toggle('open');
      });
    }

    const logoutEl = document.getElementById('acct-logout');
    if(logoutEl){
      logoutEl.addEventListener('click', ()=>{
        currentUser = null;
        persistSession(null);
        renderNav();
        showView('home');
        toast('Logged out.');
      });
    }

    wrap.querySelectorAll('[data-nav]').forEach(el=>{
      el.addEventListener('click', ()=>showView(el.getAttribute('data-nav')));
    });
  }

  renderHamburger();
  renderMemberGreeting();
  renderRecentActivity();
  renderLibDashboard();
}

function renderMemberGreeting(){
  const el = document.getElementById('member-greeting');
  if(!el || !currentUser) return;
  const hour = new Date().getHours();
  const greetWord = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';
  el.innerHTML = '👋 ' + greetWord + ', ' + currentUser.name.split(' ')[0] + '!';
}

function renderRecentActivity(){
  const grid = document.getElementById('recent-activity-grid');
  if(!grid || !currentUser) return;
  grid.innerHTML = '';

  const dueEntries = currentUser.borrowed.map(id=>{
    const book = BOOKS.find(b=>b.id===id);
    const histEntry = currentUser.history.find(h=>h.type==='Borrowed' && h.bookId===id);
    return book ? {book, ts: histEntry ? histEntry.ts : Date.now(), kind:'due'} : null;
  }).filter(Boolean);

  const returnedEntries = currentUser.history.filter(h=>h.type==='Returned').map(h=>{
    const book = BOOKS.find(b=>b.id===h.bookId);
    return book ? {book, ts:h.ts, kind:'returned'} : null;
  }).filter(Boolean);

  const combined = [...dueEntries, ...returnedEntries].sort((a,b)=>b.ts-a.ts).slice(0,3);
  if(combined.length === 0){
    grid.innerHTML = '<div class="no-results">No recent activity yet. Borrow a book to see it here.</div>';
    return;
  }

  combined.forEach(entry=>{
    const wrap = document.createElement('div');
    wrap.className = 'book';
    wrap.appendChild(coverEl(entry.book));
    const title = document.createElement('div'); title.className='book-title'; title.textContent = entry.book.title;
    const author = document.createElement('div'); author.className='book-author'; author.textContent = entry.book.author;
    const badge = document.createElement('div');
    badge.className = 'avail-badge yes';
    if(entry.kind === 'due'){
      const dueTs = entry.ts + 14*86400000;
      const daysLeft = Math.ceil((dueTs - Date.now()) / 86400000);
      if(daysLeft > 1) badge.textContent = 'Due in ' + daysLeft + ' days';
      else if(daysLeft === 1) badge.textContent = 'Due Tomorrow';
      else if(daysLeft === 0) badge.textContent = 'Due Today';
      else badge.textContent = 'Overdue by ' + Math.abs(daysLeft) + ' days';
    } else {
      const d = new Date(entry.ts);
      badge.textContent = 'Returned ' + d.toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'});
    }
    wrap.appendChild(title); wrap.appendChild(author); wrap.appendChild(badge);
    wrap.addEventListener('click', ()=>openModal(entry.book.id));
    grid.appendChild(wrap);
  });
}

function renderHamburger(){
  const menu = document.getElementById('hamburger-menu');
  if(!menu) return;
  menu.innerHTML = '';
  const items = currentUser
    ? (currentUser.role === 'Librarian'
        ? [['profile','My Profile'],['managebooks','Manage Books'],['notifications','Notifications']]
        : [['profile','My Profile'],['notifications','Notifications'],['saved','Saved Books'],['history','History Logs']])
    : [['role','Sign In'],['role','Register'],['contact','Contacts']];

  items.forEach(([key,label])=>{
    const d = document.createElement('div');
    d.textContent = label;
    d.addEventListener('click', (e)=>{ e.stopPropagation(); showView(key); menu.classList.remove('open'); });
    menu.appendChild(d);
  });
}

const hamburgerBtn = document.getElementById('hamburger-btn');
if(hamburgerBtn){
  hamburgerBtn.addEventListener('click', (e)=>{
    e.stopPropagation();
    const menu = document.getElementById('hamburger-menu');
    if(menu) menu.classList.toggle('open');
  });
}

document.addEventListener('click', ()=>{
  const m = document.getElementById('acct-menu');
  if(m) m.classList.remove('open');
  const h = document.getElementById('hamburger-menu');
  if(h) h.classList.remove('open');
});

function showView(name){
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
  const view = document.getElementById('view-'+name);
  if(view) view.classList.add('active');
  document.querySelectorAll('#nav-links a').forEach(a=>{
    a.classList.toggle('current', a.dataset.nav === name);
  });
  if(name === 'mybooks') renderMyBooks();
  if(name === 'profile') renderProfile();
  if(name === 'notifications') renderNotifications();
  if(name === 'history') renderHistory();
  if(name === 'saved') renderSaved();
  if(name === 'home'){ renderAnnouncements(); renderLibDashboard(); }
  if(name === 'gallery') renderVenueGrid();
  if(name === 'signin' || name === 'register') renderRoleBadges();
  if(name === 'managebooks') renderManageBooks();
  window.scrollTo(0,0);
}

const rgTermsLink = document.getElementById('rg-terms-link');
if(rgTermsLink){
  rgTermsLink.addEventListener('click', (e)=>{
    e.preventDefault();
    e.stopPropagation();
    showView('terms');
  });
}
const rgPrivacyLink = document.getElementById('rg-privacy-link');
if(rgPrivacyLink){
  rgPrivacyLink.addEventListener('click', (e)=>{
    e.preventDefault();
    e.stopPropagation();
    showView('privacy');
  });
}
