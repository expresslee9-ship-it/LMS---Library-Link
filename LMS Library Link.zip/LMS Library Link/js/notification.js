async function loadNotifications() {

const {

data:{session}

}=await supabaseClient.auth.getSession();

if(!session){

location.href="login.html";
return;

}

const container=document.getElementById("notificationList");

const {

data,
error

}=await supabaseClient

.from("notifications")

.select("*")

.eq("user_id",session.user.id)

.order("created_at",{ascending:false});

if(error){

container.innerHTML="Unable to load notifications.";

return;

}

if(data.length===0){

container.innerHTML="<p>No notifications found.</p>";

return;

}

container.innerHTML="";

data.forEach(item=>{

container.innerHTML+=`

<div class="notification-card">

<h3>${item.title}</h3>

<p>${item.message}</p>

<small>

${new Date(item.created_at).toLocaleString()}

</small>

</div>

`;

});

}

loadNotifications();



async function logout(){

await supabaseClient.auth.signOut();

location.href="login.html";

}