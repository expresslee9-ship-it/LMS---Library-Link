/* ===================== RENDER BOOK GRIDS ===================== */
function bookCardEl(book){
  const wrap = document.createElement('div');
  wrap.className = 'book';
  const cov = coverEl(book);
  wrap.appendChild(cov);

  const save = document.createElement('div');
  const isSaved = currentUser && currentUser.saved.includes(book.id);
  save.className = 'save-btn' + (isSaved ? ' saved' : '');
  save.textContent = isSaved ? '♥' : '♡';
  save.title = isSaved ? 'Remove from Saved Books' : 'Save for later';
  save.addEventListener('click', (e)=>{
    e.stopPropagation();
    toggleSave(book.id);
  });
  wrap.appendChild(save);

  const title = document.createElement('div'); title.className='book-title'; title.textContent = book.title;
  const author = document.createElement('div'); author.className='book-author'; author.textContent = book.author;
  const badge = document.createElement('div');
  badge.className = 'avail-badge ' + (book.available>0 ? 'yes' : 'no');
  badge.textContent = book.available>0 ? 'Available' : 'All Borrowed';
  wrap.appendChild(title); wrap.appendChild(author); wrap.appendChild(badge);
  wrap.addEventListener('click', ()=>openModal(book.id));
  return wrap;
}

function toggleSave(bookId){
  if(!currentUser){ showView('role'); return; }
  const book = BOOKS.find(b=>b.id===bookId);
  if(!book) return;
  const idx = currentUser.saved.indexOf(bookId);
  if(idx === -1){
    currentUser.saved.push(bookId);
    toast('Saved "' + book.title + '".');
  } else {
    currentUser.saved.splice(idx,1);
    toast('Removed "' + book.title + '" from Saved Books.');
  }
  persistUsers();
  renderNav();
  renderFeatured();
  renderAllBooks();
  renderSaved();
  if(activeModalBookId === bookId) refreshModalActionBtn();
}

function renderFeatured(){
  const grid = document.getElementById('featured-grid');
  if(!grid) return;
  grid.innerHTML = '';
  BOOKS.slice(0,3).forEach(b=>grid.appendChild(bookCardEl(b)));
}

function toggleBookSelection(book){
  const idx = selectedBookIds.indexOf(book.id);
  if(idx !== -1){
    selectedBookIds.splice(idx, 1);
    updateRowSelectionUI();
    return;
  }
  const sameCatIdx = selectedBookIds.findIndex(id=>{
    const b = BOOKS.find(x=>x.id===id);
    return b && b.category === book.category;
  });
  if(sameCatIdx !== -1){
    selectedBookIds.splice(sameCatIdx, 1, book.id);
    updateRowSelectionUI();
    return;
  }
  if(selectedBookIds.length >= 3){
    toast('You can select up to 3 books at a time (1 per category). Deselect one first.');
    return;
  }
  selectedBookIds.push(book.id);
  updateRowSelectionUI();
}

function updateRowSelectionUI(){
  document.querySelectorAll('.row-book').forEach(el=>{
    el.classList.toggle('selected', selectedBookIds.includes(Number(el.dataset.bookId)));
  });
  const globalBtn = document.getElementById('global-borrow-now-btn');
  if(globalBtn){
    globalBtn.classList.toggle('enabled', selectedBookIds.length > 0);
    globalBtn.textContent = selectedBookIds.length > 1 ? 'BORROW ' + selectedBookIds.length + ' NOW!' : 'BORROW NOW!';
  }
}

function rowBookEl(book){
  const wrap = document.createElement('div');
  wrap.className = 'row-book' + (selectedBookIds.includes(book.id) ? ' selected' : '');
  wrap.dataset.bookId = book.id;
  wrap.appendChild(coverEl(book));

  const badge = document.createElement('button');
  badge.className = 'avail-badge ' + (book.available>0 ? 'yes' : 'no');
  badge.textContent = book.available>0 ? 'Available' : 'Unavailable';
  badge.addEventListener('click', (e)=>{ e.stopPropagation(); openModal(book.id); });
  wrap.appendChild(badge);

  const tip = document.createElement('div');
  tip.className = 'row-tooltip';
  tip.innerHTML = `<b>Title</b>${book.title}<b>Author</b>${book.author}<b>Publish Date</b>${book.date}<b>Publisher</b>${book.publisher}<b>ISBN</b>${book.isbn}`;
  wrap.appendChild(tip);

  wrap.addEventListener('click', ()=>toggleBookSelection(book));
  return wrap;
}

function renderAllBooks(){
  const grid = document.getElementById('all-books-grid');
  if(!grid) return;
  const searchEl = document.getElementById('books-search');
  const catEl = document.getElementById('books-category');
  const q = searchEl ? searchEl.value.trim().toLowerCase() : '';
  const catFilter = catEl ? catEl.value : '';
  const cats = catFilter ? [catFilter] : CATEGORIES;

  const scrollMap = {};
  grid.querySelectorAll('.cat-row').forEach(r=>{ scrollMap[r.dataset.cat] = r.scrollLeft; });

  grid.innerHTML = '';
  let anyResults = false;

  cats.forEach(cat=>{
    const inCat = BOOKS.filter(b=>{
      const matchQ = !q || b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q);
      return b.category === cat && matchQ;
    });
    if(inCat.length === 0) return;
    anyResults = true;

    const section = document.createElement('div');
    section.className = 'cat-row-section';
    section.dataset.cat = cat;

    const title = document.createElement('div');
    title.className = 'cat-row-title';
    title.textContent = cat;
    section.appendChild(title);

    const rowWrap = document.createElement('div');
    rowWrap.className = 'cat-row-wrap';
    const row = document.createElement('div');
    row.className = 'cat-row';
    row.dataset.cat = cat;
    inCat.forEach(b=>row.appendChild(rowBookEl(b)));
    const arrow = document.createElement('button');
    arrow.className = 'cat-row-arrow';
    arrow.textContent = '›';
    arrow.addEventListener('click', ()=>row.scrollBy({left: 340, behavior:'smooth'}));
    rowWrap.appendChild(row);
    rowWrap.appendChild(arrow);
    section.appendChild(rowWrap);

    grid.appendChild(section);
  });

  updateRowSelectionUI();

  if(!anyResults){
    grid.innerHTML = '<div class="no-results">No books match your search. Try a different title, author, or category.</div>';
    return;
  }

  grid.querySelectorAll('.cat-row').forEach(r=>{
    if(scrollMap[r.dataset.cat] !== undefined) r.scrollLeft = scrollMap[r.dataset.cat];
  });
}

/* ===================== MODAL ===================== */
function openModal(id){
  const book = BOOKS.find(b=>b.id===id);
  if(!book) return;
  activeModalBookId = id;
  const cov = document.getElementById('modal-cover');
  if(cov){
    cov.style.background = COVER_COLORS[book.category];
    const titleEl = cov.querySelector('.t');
    if(titleEl) titleEl.textContent = book.title;
  }
  const setText = (id, value)=>{
    const el = document.getElementById(id);
    if(el) el.textContent = value;
  };
  setText('modal-title', book.title);
  setText('modal-author', 'by ' + book.author);
  setText('modal-date', book.date);
  setText('modal-publisher', book.publisher);
  setText('modal-isbn', book.isbn);
  setText('modal-cat', book.category);
  setText('modal-copies', book.available + ' / ' + book.copies);
  refreshModalActionBtn();
  const overlay = document.getElementById('modal-overlay');
  if(overlay) overlay.classList.add('open');
}
function closeModal(){
  const overlay = document.getElementById('modal-overlay');
  if(overlay) overlay.classList.remove('open');
  activeModalBookId = null;
}
const modalClose = document.getElementById('modal-close');
if(modalClose) modalClose.addEventListener('click', closeModal);
const modalOverlay = document.getElementById('modal-overlay');
if(modalOverlay){
  modalOverlay.addEventListener('click', (e)=>{
    if(e.target.id === 'modal-overlay') closeModal();
  });
}

function refreshModalActionBtn(){
  const btn = document.getElementById('modal-action-btn');
  const saveBtn = document.getElementById('modal-save-btn');
  const book = BOOKS.find(b=>b.id===activeModalBookId);
  if(!book || !btn || !saveBtn) return;
  const alreadyBorrowedByUser = currentUser && currentUser.borrowed.includes(book.id);
  btn.disabled = false;
  if(!currentUser){
    btn.textContent = 'Sign In to Borrow';
    btn.className = 'btn';
    btn.onclick = ()=>{ closeModal(); showView('role'); };
  } else if(alreadyBorrowedByUser){
    btn.textContent = 'Return This Book';
    btn.className = 'btn dark';
    btn.onclick = ()=>{ returnBook(book.id); refreshModalActionBtn(); const d = document.getElementById('modal-copies'); if(d) d.textContent = book.available + ' / ' + book.copies; };
  } else if(book.available <= 0){
    btn.textContent = 'No Copies Available';
    btn.className = 'btn';
    btn.disabled = true;
  } else {
    btn.textContent = 'Borrow This Book';
    btn.className = 'btn';
    btn.onclick = ()=>{ borrowBook(book.id); refreshModalActionBtn(); const d = document.getElementById('modal-copies'); if(d) d.textContent = book.available + ' / ' + book.copies; };
  }
  const isSaved = currentUser && currentUser.saved.includes(book.id);
  saveBtn.textContent = isSaved ? '♥ Saved' : '♡ Save for Later';
  saveBtn.onclick = ()=>toggleSave(book.id);
}

/* ===================== BORROW / RETURN ===================== */
function borrowBook(id){
  const result = borrowBookCore(id);
  if(result.ok){
    renderNav();
    renderFeatured();
    renderAllBooks();
    toast('Borrowed "' + result.book.title + '".');
    return true;
  }
  if(result.reason === 'category-limit'){
    toast('You can only borrow 1 book per category. Return your ' + result.book.category + ' book first.');
  } else if(result.reason === 'unavailable' && result.book){
    toast('No copies of "' + result.book.title + '" available.');
  }
  return false;
}

function borrowBookCore(id){
  const book = BOOKS.find(b=>b.id===id);
  if(!currentUser || !book) return {ok:false, reason:'no-user'};
  if(book.available<=0) return {ok:false, reason:'unavailable', book};
  const alreadyInCategory = currentUser.borrowed.some(bid=>{
    const bb = BOOKS.find(x=>x.id===bid);
    return bb && bb.category === book.category;
  });
  if(alreadyInCategory) return {ok:false, reason:'category-limit', book};
  book.available -= 1;
  currentUser.borrowed.push(id);
  currentUser.history.unshift({type:'Borrowed', title:book.title, bookId:book.id, ts:Date.now(), when:new Date().toLocaleString()});
  persistBooks();
  persistUsers();
  return {ok:true, book};
}

function returnBook(id){
  const book = BOOKS.find(b=>b.id===id);
  if(!currentUser || !book) return;
  const idx = currentUser.borrowed.indexOf(id);
  if(idx === -1) return;
  currentUser.borrowed.splice(idx,1);
  book.available += 1;
  currentUser.history.unshift({type:'Returned', title:book.title, bookId:book.id, ts:Date.now(), when:new Date().toLocaleString()});
  persistBooks();
  persistUsers();
  renderNav();
  renderFeatured();
  renderAllBooks();
  renderMyBooks();
  toast('Returned "' + book.title + '".');
}

const globalBorrowNowBtn = document.getElementById('global-borrow-now-btn');
if(globalBorrowNowBtn){
  globalBorrowNowBtn.addEventListener('click', ()=>{
    if(selectedBookIds.length === 0) return;
    if(!currentUser){ showView('role'); toast('Please sign in to borrow books.'); return; }
    let successTitles = [];
    let failMessages = [];
    selectedBookIds.slice().forEach(id=>{
      const book = BOOKS.find(b=>b.id===id);
      if(!book) return;
      if(currentUser.borrowed.includes(book.id)){ failMessages.push(book.title + ' (already borrowed)'); return; }
      const result = borrowBookCore(id);
      if(result.ok) successTitles.push(result.book.title);
      else if(result.reason === 'unavailable') failMessages.push(book.title + ' (no copies left)');
      else if(result.reason === 'category-limit') failMessages.push(book.title + ' (category limit)');
    });
    selectedBookIds = [];
    renderNav();
    renderFeatured();
    renderAllBooks();
    if(successTitles.length && failMessages.length === 0){
      toast('Borrowed ' + successTitles.length + (successTitles.length > 1 ? ' books.' : ' book: "' + successTitles[0] + '".'));
    } else if(successTitles.length && failMessages.length){
      toast('Borrowed ' + successTitles.length + ', skipped ' + failMessages.length + '.');
    } else {
      toast('Could not borrow the selected book' + (failMessages.length > 1 ? 's' : '') + '.');
    }
  });
}
