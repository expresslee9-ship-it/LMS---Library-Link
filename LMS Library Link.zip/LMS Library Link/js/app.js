/* Safe helpers: only define when not already present to avoid collisions */
(function(){
  window.escapeHtml = window.escapeHtml || function(str){
    const d = document.createElement('div');
    d.textContent = String(str == null ? '' : str);
    return d.innerHTML;
  };

  window.toast = window.toast || function(text){
    const t = document.getElementById('toast');
    if(!t) return;
    t.textContent = text;
    t.classList.add('show');
    clearTimeout(t._h);
    t._h = setTimeout(()=>t.classList.remove('show'), 2400);
  };

  window.coverEl = window.coverEl || function(book){
    const div = document.createElement('div');
    div.className = 'cover';
    div.style.background = (window.COVER_COLORS && window.COVER_COLORS[book.category]) || 'linear-gradient(160deg,#8a5a3c,#6b4226)';
    div.innerHTML = `<div class="t">${book.title}</div><div class="a">${book.author}</div>`;
    const img = document.createElement('img');
    img.className = 'cover-img'; img.loading = 'lazy'; img.alt = book.title + ' cover';
    img.src = 'https://covers.openlibrary.org/b/isbn/' + encodeURIComponent(book.isbn) + '-M.jpg';
    img.addEventListener('load', ()=>{ if(img.naturalWidth < 10) img.remove(); });
    img.addEventListener('error', ()=>img.remove());
    div.appendChild(img);
    return div;
  };

  window.populateCategorySelects = window.populateCategorySelects || function(){
    document.querySelectorAll('#hero-category, #books-category, #member-category').forEach(sel=>{
      if(!sel) return;
      (window.CATEGORIES||[]).forEach(c=>{
        const o = document.createElement('option'); o.value = c; o.textContent = c; sel.appendChild(o);
      });
    });
  };

  window.populateCategoryGrid = window.populateCategoryGrid || function(){
    const grid = document.getElementById('category-grid');
    if(!grid) return;
    grid.innerHTML = '';
    (window.CATEGORIES||[]).forEach(c=>{
      const btn = document.createElement('button');
      btn.className = 'category-pill'; btn.textContent = c;
      btn.style.background = (window.COVER_COLORS && window.COVER_COLORS[c]) || 'var(--brown)';
      btn.addEventListener('click', ()=>window.goToBooksWithFilters && window.goToBooksWithFilters('', c));
      grid.appendChild(btn);
    });
  };

})();

/* Initialize Supabase client if available from CDN and config present */
(function(){
  try{
    if(typeof SUPABASE_URL !== 'undefined' && typeof SUPABASE_ANON_KEY !== 'undefined' && typeof supabase !== 'undefined'){
      const isClient = !!(window.supabase && window.supabase.auth && typeof window.supabase.auth.signInWithOAuth === 'function');
      if(!isClient){
        window.supabase = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
      }
    }
  }catch(e){
    console.warn('Supabase init failed', e);
  }
})();
