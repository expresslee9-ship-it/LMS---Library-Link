/* ===================== LIBRARY LINK - COMPLETE APPLICATION ===================== */

/* Helpers are provided by `js/app.js` to avoid duplicates across modules. */

/* ===================== PERSISTENCE ===================== */
function persistBooks(){
  if(!window.storage) return;
  window.storage.set(STORAGE_BOOKS_KEY, JSON.stringify(BOOKS), true).catch(()=>{});
}
function persistUsers(){
  if(!window.storage) return;
  window.storage.set(STORAGE_USERS_KEY, JSON.stringify(USERS), false).catch(()=>{});
}
function persistSession(email){
  if(!window.storage) return;
  if(email){
    window.storage.set(STORAGE_SESSION_KEY, JSON.stringify({email}), false).catch(()=>{});
  } else {
    window.storage.delete(STORAGE_SESSION_KEY, false).catch(()=>{});
  }
}

async function loadPersistedState(){
  if(!window.storage) return;
  try{
    const res = await window.storage.get(STORAGE_BOOKS_KEY, true);
    if(res && res.value){
      const parsed = JSON.parse(res.value);
      if(Array.isArray(parsed) && parsed.length) BOOKS = parsed;
    }
  }catch(e){ }
  try{
    const res = await window.storage.get(STORAGE_USERS_KEY, false);
    if(res && res.value){
      const parsed = JSON.parse(res.value);
      if(Array.isArray(parsed) && parsed.length) USERS = parsed;
    }
  }catch(e){ }
  try{
    const res = await window.storage.get(STORAGE_SESSION_KEY, false);
    if(res && res.value){
      const { email } = JSON.parse(res.value);
      const found = USERS.find(u=>u.email === email);
      if(found) currentUser = found;
    }
  }catch(e){ }
}

/* ===================== LIVE SEARCH SUGGESTIONS ===================== */
function renderSearchSuggestions(query, dropdownEl, categoryElId){
  const q = query.trim().toLowerCase();
  if(!q){
    dropdownEl.classList.remove('open');
    dropdownEl.innerHTML = '';
    return;
  }
  const matches = BOOKS.filter(b =>
    b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q) || b.category.toLowerCase().includes(q)
  );
  dropdownEl.innerHTML = '';
  if(matches.length === 0){
    dropdownEl.innerHTML = '<div class="sr-empty">No books match "' + query.trim() + '".</div>';
    dropdownEl.classList.add('open');
    return;
  }
  matches.slice(0,6).forEach(book=>{
    const row = document.createElement('div');
    row.className = 'sr-item';
    const swatch = document.createElement('div');
    swatch.className = 'sr-swatch';
    swatch.style.background = COVER_COLORS[book.category] || 'var(--brown)';
    const info = document.createElement('div');
    info.className = 'sr-info';
    info.innerHTML = `<div class="sr-title">${book.title}</div><div class="sr-author">${book.author} · ${book.category}</div>`;
    const badge = document.createElement('div');
    badge.className = 'sr-avail ' + (book.available>0 ? 'yes' : 'no');
    badge.textContent = book.available>0 ? 'Available' : 'Borrowed';
    row.appendChild(swatch); row.appendChild(info); row.appendChild(badge);
    row.addEventListener('click', ()=>{
      dropdownEl.classList.remove('open');
      openModal(book.id);
    });
    dropdownEl.appendChild(row);
  });
  if(matches.length > 6){
    const more = document.createElement('div');
    more.className = 'sr-more';
    more.textContent = 'See all ' + matches.length + ' results';
    more.addEventListener('click', ()=>{
      dropdownEl.classList.remove('open');
      const cat = categoryElId ? document.getElementById(categoryElId).value : '';
      goToBooksWithFilters(query, cat);
    });
    dropdownEl.appendChild(more);
  }
  dropdownEl.classList.add('open');
}

function initSearchBar(inputId, resultsId, categoryId){
  const input = document.getElementById(inputId);
  const results = document.getElementById(resultsId);
  if(!input || !results) return;
  input.addEventListener('input', ()=>{
    renderSearchSuggestions(input.value, results, categoryId);
  });
  input.addEventListener('focus', ()=>{
    if(input.value.trim()) renderSearchSuggestions(input.value, results, categoryId);
  });
  input.addEventListener('keydown', (e)=>{
    if(e.key === 'Escape'){ results.classList.remove('open'); input.blur(); }
    if(e.key === 'Enter'){
      results.classList.remove('open');
      const cat = categoryId ? document.getElementById(categoryId).value : '';
      goToBooksWithFilters(input.value, cat);
    }
  });
  const categoryEl = categoryId ? document.getElementById(categoryId) : null;
  if(categoryEl){
    categoryEl.addEventListener('change', (e)=>{
      results.classList.remove('open');
      goToBooksWithFilters(input.value, e.target.value);
    });
  }
}

document.addEventListener('click', (e)=>{
  document.querySelectorAll('.search-results.open').forEach(dd=>{
    const wrap = dd.closest('.search-bar-wrap');
    if(wrap && !wrap.contains(e.target)) dd.classList.remove('open');
  });
});

/* ===================== NAV / VIEWS ===================== */
function renderNavLinks(){
  const nav = document.getElementById('nav-links');
  nav.innerHTML = '';
  const links = currentUser
    ? (currentUser.role === 'Librarian'
        ? [['home','Home'],['managebooks','Manage Books'],['books','Books'],['notifications','Notifications'],['profile','My Profile']]
        : [['home','Home'],['notifications','Notifications'],['books','Books'],['history','History Logs'],['saved','Saved Books']])
    : [['home','Home'],['books','Books'],['contact','Contacts']];
  links.forEach(([key,label])=>{
    const a = document.createElement('a');
    a.textContent = label;
    a.dataset.nav = key;
    a.addEventListener('click', ()=>showView(key));
    nav.appendChild(a);
  });
  if(!currentUser){
    const login = document.createElement('a');
    login.textContent = 'Login';
    login.id = 'nav-login';
    login.addEventListener('click', ()=>showView('role'));
    nav.appendChild(login);
  }
}

function renderNav(){
  renderNavLinks();
  const slot = document.getElementById('nav-auth-slot');
  slot.innerHTML = '';
  const isLibrarianUser = currentUser && currentUser.role === 'Librarian';
  document.getElementById('home-guest').style.display = currentUser ? 'none' : 'block';
  document.getElementById('home-reader').style.display = (currentUser && !isLibrarianUser) ? 'block' : 'none';
  document.getElementById('home-librarian').style.display = isLibrarianUser ? 'block' : 'none';
  if(currentUser){
    const wrap = document.createElement('div');
    wrap.className = 'acct';
    wrap.innerHTML = `
      <div class="acct-btn" id="acct-btn">👤 ${currentUser.name.split(' ')[0]} ▾</div>
      <div class="acct-menu" id="acct-menu">
        ${currentUser.role === 'Librarian'
          ? `<div data-nav="profile">👤 My Profile</div>
             <div data-nav="managebooks">🗂 Manage Books</div>`
          : `<div data-nav="profile">👤 My Profile</div>
             <div data-nav="mybooks">My Books (${currentUser.borrowed.length})</div>
             <div data-nav="saved">Saved Books (${currentUser.saved.length})</div>`
        }
        <div id="acct-logout">Log Out</div>
      </div>`;
    slot.appendChild(wrap);
    document.getElementById('acct-btn').addEventListener('click', (e)=>{
      e.stopPropagation();
      document.getElementById('acct-menu').classList.toggle('open');
    });
    document.getElementById('acct-logout').addEventListener('click', ()=>{
      currentUser = null;
      persistSession(null);
      renderNav();
      showView('home');
      toast('Logged out.');
    });
    wrap.querySelectorAll('[data-nav]').forEach(el=>{
      el.addEventListener('click', ()=>showView(el.getAttribute('data-nav')));
    });
  }
  renderHamburger();
  renderMemberGreeting();
  renderRecentActivity();
  renderLibDashboard();
}

function renderMemberGreeting(){
  const el = document.getElementById('member-greeting');
  if(!el || !currentUser) return;
  const hour = new Date().getHours();
  const greetWord = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';
  el.innerHTML = '👋 ' + greetWord + ', ' + currentUser.name.split(' ')[0] + '!';
}

function renderRecentActivity(){
  const grid = document.getElementById('recent-activity-grid');
  if(!grid || !currentUser) return;
  grid.innerHTML = '';
  const dueEntries = currentUser.borrowed.map(id=>{
    const book = BOOKS.find(b=>b.id===id);
    const histEntry = currentUser.history.find(h=>h.type==='Borrowed' && h.bookId===id);
    return book ? {book, ts: histEntry ? histEntry.ts : Date.now(), kind:'due'} : null;
  }).filter(Boolean);
  const returnedEntries = currentUser.history.filter(h=>h.type==='Returned').map(h=>{
    const book = BOOKS.find(b=>b.id===h.bookId);
    return book ? {book, ts:h.ts, kind:'returned'} : null;
  }).filter(Boolean);
  const combined = [...dueEntries, ...returnedEntries].sort((a,b)=>b.ts-a.ts).slice(0,3);
  if(combined.length === 0){
    grid.innerHTML = '<div class="no-results">No recent activity yet. Borrow a book to see it here.</div>';
    return;
  }
  combined.forEach(entry=>{
    const wrap = document.createElement('div');
    wrap.className = 'book';
    wrap.appendChild(coverEl(entry.book));
    const title = document.createElement('div'); title.className='book-title'; title.textContent = entry.book.title;
    const author = document.createElement('div'); author.className='book-author'; author.textContent = entry.book.author;
    const badge = document.createElement('div');
    badge.className = 'avail-badge yes';
    if(entry.kind === 'due'){
      const dueTs = entry.ts + 14*86400000;
      const daysLeft = Math.ceil((dueTs - Date.now()) / 86400000);
      if(daysLeft > 1) badge.textContent = 'Due in ' + daysLeft + ' days';
      else if(daysLeft === 1) badge.textContent = 'Due Tomorrow';
      else if(daysLeft === 0) badge.textContent = 'Due Today';
      else badge.textContent = 'Overdue by ' + Math.abs(daysLeft) + ' days';
    } else {
      const d = new Date(entry.ts);
      badge.textContent = 'Returned ' + d.toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'});
    }
    wrap.appendChild(title); wrap.appendChild(author); wrap.appendChild(badge);
    wrap.addEventListener('click', ()=>openModal(entry.book.id));
    grid.appendChild(wrap);
  });
}

function renderHamburger(){
  const menu = document.getElementById('hamburger-menu');
  menu.innerHTML = '';
  const items = currentUser
    ? (currentUser.role === 'Librarian'
        ? [['profile','My Profile'],['managebooks','Manage Books'],['notifications','Notifications']]
        : [['profile','My Profile'],['notifications','Notifications'],['saved','Saved Books'],['history','History Logs']])
    : [['role','Sign In'],['role','Register'],['contact','Contacts']];
  items.forEach(([key,label])=>{
    const d = document.createElement('div');
    d.textContent = label;
    d.addEventListener('click', (e)=>{ e.stopPropagation(); showView(key); menu.classList.remove('open'); });
    menu.appendChild(d);
  });
}
document.getElementById('hamburger-btn').addEventListener('click', (e)=>{
  e.stopPropagation();
  document.getElementById('hamburger-menu').classList.toggle('open');
});
document.addEventListener('click', ()=>{
  const m = document.getElementById('acct-menu');
  if(m) m.classList.remove('open');
  const h = document.getElementById('hamburger-menu');
  if(h) h.classList.remove('open');
});

function showView(name){
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
  document.getElementById('view-'+name).classList.add('active');
  document.querySelectorAll('#nav-links a').forEach(a=>{
    a.classList.toggle('current', a.dataset.nav === name);
  });
  if(name === 'mybooks') renderMyBooks();
  if(name === 'profile') renderProfile();
  if(name === 'notifications') renderNotifications();
  if(name === 'history') renderHistory();
  if(name === 'saved') renderSaved();
  if(name === 'home'){ renderAnnouncements(); renderLibDashboard(); }
  if(name === 'gallery') renderVenueGrid();
  if(name === 'signin' || name === 'register') renderRoleBadges();
  if(name === 'managebooks') renderManageBooks();
  window.scrollTo(0,0);
}

document.querySelectorAll('[data-nav]').forEach(el=>{
  el.addEventListener('click', ()=>showView(el.getAttribute('data-nav')));
});
document.getElementById('rg-terms-link').addEventListener('click', (e)=>{
  e.preventDefault();
  e.stopPropagation();
  showView('terms');
});
document.getElementById('rg-privacy-link').addEventListener('click', (e)=>{
  e.preventDefault();
  e.stopPropagation();
  showView('privacy');
});

/* ===================== RENDER BOOK GRIDS ===================== */
function bookCardEl(book){
  const wrap = document.createElement('div');
  wrap.className = 'book';
  const cov = coverEl(book);
  wrap.appendChild(cov);

  const save = document.createElement('div');
  const isSaved = currentUser && currentUser.saved.includes(book.id);
  save.className = 'save-btn' + (isSaved ? ' saved' : '');
  save.textContent = isSaved ? '♥' : '♡';
  save.title = isSaved ? 'Remove from Saved Books' : 'Save for later';
  save.addEventListener('click', (e)=>{
    e.stopPropagation();
    toggleSave(book.id);
  });
  wrap.appendChild(save);

  const title = document.createElement('div'); title.className='book-title'; title.textContent = book.title;
  const author = document.createElement('div'); author.className='book-author'; author.textContent = book.author;
  const badge = document.createElement('div');
  badge.className = 'avail-badge ' + (book.available>0 ? 'yes' : 'no');
  badge.textContent = book.available>0 ? 'Available' : 'All Borrowed';
  wrap.appendChild(title); wrap.appendChild(author); wrap.appendChild(badge);
  wrap.addEventListener('click', ()=>openModal(book.id));
  return wrap;
}

function toggleSave(bookId){
  if(!currentUser){ showView('role'); return; }
  const book = BOOKS.find(b=>b.id===bookId);
  const idx = currentUser.saved.indexOf(bookId);
  if(idx === -1){
    currentUser.saved.push(bookId);
    toast('Saved "' + book.title + '".');
  } else {
    currentUser.saved.splice(idx,1);
    toast('Removed "' + book.title + '" from Saved Books.');
  }
  persistUsers();
  renderNav();
  renderFeatured();
  renderAllBooks();
  renderSaved();
  if(activeModalBookId === bookId) refreshModalActionBtn();
}

function renderFeatured(){
  const grid = document.getElementById('featured-grid');
  grid.innerHTML = '';
  BOOKS.slice(0,3).forEach(b=>grid.appendChild(bookCardEl(b)));
}

function toggleBookSelection(book){
  const idx = selectedBookIds.indexOf(book.id);
  if(idx !== -1){
    selectedBookIds.splice(idx, 1);
    updateRowSelectionUI();
    return;
  }
  const sameCatIdx = selectedBookIds.findIndex(id=>{
    const b = BOOKS.find(x=>x.id===id);
    return b && b.category === book.category;
  });
  if(sameCatIdx !== -1){
    selectedBookIds.splice(sameCatIdx, 1, book.id);
    updateRowSelectionUI();
    return;
  }
  if(selectedBookIds.length >= 3){
    toast('You can select up to 3 books at a time (1 per category). Deselect one first.');
    return;
  }
  selectedBookIds.push(book.id);
  updateRowSelectionUI();
}

function updateRowSelectionUI(){
  document.querySelectorAll('.row-book').forEach(el=>{
    el.classList.toggle('selected', selectedBookIds.includes(Number(el.dataset.bookId)));
  });
  const globalBtn = document.getElementById('global-borrow-now-btn');
  if(globalBtn){
    globalBtn.classList.toggle('enabled', selectedBookIds.length > 0);
    globalBtn.textContent = selectedBookIds.length > 1 ? 'BORROW ' + selectedBookIds.length + ' NOW!' : 'BORROW NOW!';
  }
}

function rowBookEl(book){
  const wrap = document.createElement('div');
  wrap.className = 'row-book' + (selectedBookIds.includes(book.id) ? ' selected' : '');
  wrap.dataset.bookId = book.id;
  wrap.appendChild(coverEl(book));

  const badge = document.createElement('button');
  badge.className = 'avail-badge ' + (book.available>0 ? 'yes' : 'no');
  badge.textContent = book.available>0 ? 'Available' : 'Unavailable';
  badge.addEventListener('click', (e)=>{ e.stopPropagation(); openModal(book.id); });
  wrap.appendChild(badge);

  const tip = document.createElement('div');
  tip.className = 'row-tooltip';
  tip.innerHTML = `<b>Title</b>${book.title}<b>Author</b>${book.author}<b>Publish Date</b>${book.date}<b>Publisher</b>${book.publisher}<b>ISBN</b>${book.isbn}`;
  wrap.appendChild(tip);

  wrap.addEventListener('click', ()=>toggleBookSelection(book));
  return wrap;
}

function renderAllBooks(){
  const grid = document.getElementById('all-books-grid');
  const q = document.getElementById('books-search').value.trim().toLowerCase();
  const catFilter = document.getElementById('books-category').value;
  const cats = catFilter ? [catFilter] : CATEGORIES;

  const scrollMap = {};
  grid.querySelectorAll('.cat-row').forEach(r=>{ scrollMap[r.dataset.cat] = r.scrollLeft; });

  grid.innerHTML = '';
  let anyResults = false;

  cats.forEach(cat=>{
    const inCat = BOOKS.filter(b=>{
      const matchQ = !q || b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q);
      return b.category === cat && matchQ;
    });
    if(inCat.length === 0) return;
    anyResults = true;

    const section = document.createElement('div');
    section.className = 'cat-row-section';
    section.dataset.cat = cat;

    const title = document.createElement('div');
    title.className = 'cat-row-title';
    title.textContent = cat;
    section.appendChild(title);

    const rowWrap = document.createElement('div');
    rowWrap.className = 'cat-row-wrap';
    const row = document.createElement('div');
    row.className = 'cat-row';
    row.dataset.cat = cat;
    inCat.forEach(b=>row.appendChild(rowBookEl(b)));
    const arrow = document.createElement('button');
    arrow.className = 'cat-row-arrow';
    arrow.textContent = '›';
    arrow.addEventListener('click', ()=>row.scrollBy({left: 340, behavior:'smooth'}));
    rowWrap.appendChild(row);
    rowWrap.appendChild(arrow);
    section.appendChild(rowWrap);

    grid.appendChild(section);
  });

  updateRowSelectionUI();

  if(!anyResults){
    grid.innerHTML = '<div class="no-results">No books match your search. Try a different title, author, or category.</div>';
    return;
  }

  grid.querySelectorAll('.cat-row').forEach(r=>{
    if(scrollMap[r.dataset.cat] !== undefined) r.scrollLeft = scrollMap[r.dataset.cat];
  });
}

/* ===================== MODAL ===================== */
function openModal(id){
  const book = BOOKS.find(b=>b.id===id);
  if(!book) return;
  activeModalBookId = id;
  const cov = document.getElementById('modal-cover');
  cov.style.background = COVER_COLORS[book.category];
  cov.querySelector('.t').textContent = book.title;
  document.getElementById('modal-title').textContent = book.title;
  document.getElementById('modal-author').textContent = 'by ' + book.author;
  document.getElementById('modal-date').textContent = book.date;
  document.getElementById('modal-publisher').textContent = book.publisher;
  document.getElementById('modal-isbn').textContent = book.isbn;
  document.getElementById('modal-cat').textContent = book.category;
  document.getElementById('modal-copies').textContent = book.available + ' / ' + book.copies;
  refreshModalActionBtn();
  document.getElementById('modal-overlay').classList.add('open');
}
function closeModal(){
  document.getElementById('modal-overlay').classList.remove('open');
  activeModalBookId = null;
}
document.getElementById('modal-close').addEventListener('click', closeModal);
document.getElementById('modal-overlay').addEventListener('click', (e)=>{
  if(e.target.id === 'modal-overlay') closeModal();
});

function refreshModalActionBtn(){
  const btn = document.getElementById('modal-action-btn');
  const saveBtn = document.getElementById('modal-save-btn');
  const book = BOOKS.find(b=>b.id===activeModalBookId);
  if(!book) return;
  const alreadyBorrowedByUser = currentUser && currentUser.borrowed.includes(book.id);
  btn.disabled = false;
  if(!currentUser){
    btn.textContent = 'Sign In to Borrow';
    btn.className = 'btn';
    btn.onclick = ()=>{ closeModal(); showView('role'); };
  } else if(alreadyBorrowedByUser){
    btn.textContent = 'Return This Book';
    btn.className = 'btn dark';
    btn.onclick = ()=>{ returnBook(book.id); refreshModalActionBtn(); document.getElementById('modal-copies').textContent = book.available + ' / ' + book.copies; };
  } else if(book.available <= 0){
    btn.textContent = 'No Copies Available';
    btn.className = 'btn';
    btn.disabled = true;
  } else {
    btn.textContent = 'Borrow This Book';
    btn.className = 'btn';
    btn.onclick = ()=>{ borrowBook(book.id); refreshModalActionBtn(); document.getElementById('modal-copies').textContent = book.available + ' / ' + book.copies; };
  }
  const isSaved = currentUser && currentUser.saved.includes(book.id);
  saveBtn.textContent = isSaved ? '♥ Saved' : '♡ Save for Later';
  saveBtn.onclick = ()=>toggleSave(book.id);
}

/* ===================== BORROW / RETURN ===================== */
function borrowBook(id){
  const result = borrowBookCore(id);
  if(result.ok){
    renderNav();
    renderFeatured();
    renderAllBooks();
    toast('Borrowed "' + result.book.title + '".');
    return true;
  }
  if(result.reason === 'category-limit'){
    toast('You can only borrow 1 book per category. Return your ' + result.book.category + ' book first.');
  } else if(result.reason === 'unavailable' && result.book){
    toast('No copies of "' + result.book.title + '" available.');
  }
  return false;
}

function borrowBookCore(id){
  const book = BOOKS.find(b=>b.id===id);
  if(!currentUser || !book) return {ok:false, reason:'no-user'};
  if(book.available<=0) return {ok:false, reason:'unavailable', book};
  const alreadyInCategory = currentUser.borrowed.some(bid=>{
    const bb = BOOKS.find(x=>x.id===bid);
    return bb && bb.category === book.category;
  });
  if(alreadyInCategory) return {ok:false, reason:'category-limit', book};
  book.available -= 1;
  currentUser.borrowed.push(id);
  currentUser.history.unshift({type:'Borrowed', title:book.title, bookId:book.id, ts:Date.now(), when:new Date().toLocaleString()});
  persistBooks();
  persistUsers();
  return {ok:true, book};
}
function returnBook(id){
  const book = BOOKS.find(b=>b.id===id);
  if(!currentUser || !book) return;
  const idx = currentUser.borrowed.indexOf(id);
  if(idx === -1) return;
  currentUser.borrowed.splice(idx,1);
  book.available += 1;
  currentUser.history.unshift({type:'Returned', title:book.title, bookId:book.id, ts:Date.now(), when:new Date().toLocaleString()});
  persistBooks();
  persistUsers();
  renderNav();
  renderFeatured();
  renderAllBooks();
  renderMyBooks();
  toast('Returned "' + book.title + '".');
}

/* ===================== ANNOUNCEMENTS ===================== */
function renderAnnouncements(){
  ['ann-pills','ann-pills-public','ann-pills-lib'].forEach(containerId=>{
    const wrap = document.getElementById(containerId);
    if(!wrap) return;
    wrap.innerHTML = '';
    if(annTimers[containerId]) clearInterval(annTimers[containerId]);

    const slideshow = document.createElement('div');
    slideshow.className = 'ann-slideshow';
    ANNOUNCEMENTS.forEach((a, i)=>{
      const slide = document.createElement('div');
      slide.className = 'ann-slide' + (i === 0 ? ' active' : '');
      slide.innerHTML = `<div class="icon">${a.icon}</div><h3>${a.title}</h3><p>${a.body}</p><div class="tap-hint">Tap to read more</div>`;
      slide.addEventListener('click', ()=>openInfoModal(a.id));
      slideshow.appendChild(slide);
    });
    wrap.appendChild(slideshow);

    const dots = document.createElement('div');
    dots.className = 'ann-dots';
    ANNOUNCEMENTS.forEach((a, i)=>{
      const dot = document.createElement('button');
      dot.className = 'ann-dot' + (i === 0 ? ' active' : '');
      dot.addEventListener('click', (e)=>{
        e.stopPropagation();
        goToAnnSlide(wrap, i);
        restartAnnTimer(containerId, wrap);
      });
      dots.appendChild(dot);
    });
    wrap.appendChild(dots);

    restartAnnTimer(containerId, wrap);
    slideshow.addEventListener('mouseenter', ()=>clearInterval(annTimers[containerId]));
    slideshow.addEventListener('mouseleave', ()=>restartAnnTimer(containerId, wrap));
  });
}

function goToAnnSlide(wrap, index){
  wrap.querySelectorAll('.ann-slide').forEach((s,i)=>s.classList.toggle('active', i===index));
  wrap.querySelectorAll('.ann-dot').forEach((d,i)=>d.classList.toggle('active', i===index));
}

function restartAnnTimer(containerId, wrap){
  clearInterval(annTimers[containerId]);
  annTimers[containerId] = setInterval(()=>{
    const dots = wrap.querySelectorAll('.ann-dot');
    let current = 0;
    dots.forEach((d,i)=>{ if(d.classList.contains('active')) current = i; });
    goToAnnSlide(wrap, (current + 1) % ANNOUNCEMENTS.length);
  }, 4000);
}
function openInfoModal(id){
  const a = ANNOUNCEMENTS.find(x=>x.id===id);
  if(!a) return;
  document.getElementById('info-title').textContent = a.title;
  document.getElementById('info-date').textContent = a.date;
  document.getElementById('info-body').textContent = a.body;
  document.getElementById('info-overlay').classList.add('open');
}
document.getElementById('info-close').addEventListener('click', ()=>{
  document.getElementById('info-overlay').classList.remove('open');
});
document.getElementById('info-overlay').addEventListener('click', (e)=>{
  if(e.target.id === 'info-overlay') document.getElementById('info-overlay').classList.remove('open');
});

/* ===================== LIBRARY GALLERY ===================== */
function venuePhotoImg(venue){
  const img = document.createElement('img');
  img.className = 'venue-photo';
  img.loading = 'lazy';
  img.alt = venue.title;
  img.src = 'https://picsum.photos/seed/' + encodeURIComponent(venue.photo) + '/500/360';
  img.addEventListener('error', ()=>img.remove());
  img.addEventListener('load', ()=>{ if(img.naturalWidth < 10) img.remove(); });
  return img;
}

function renderHomeGalleryPreview(){
  const wrap = document.getElementById('home-gallery-preview');
  if(!wrap) return;
  wrap.innerHTML = '';
  VENUES.slice(0,4).forEach(v=>{
    const tile = document.createElement('div');
    tile.className = 'gallery-tile';
    tile.style.background = v.gradient;
    tile.appendChild(venuePhotoImg(v));
    const scrim = document.createElement('div');
    scrim.className = 'venue-scrim';
    tile.appendChild(scrim);
    const label = document.createElement('span');
    label.className = 'tile-label';
    label.textContent = v.title;
    tile.appendChild(label);
    tile.addEventListener('click', ()=>openVenueModal(v.id));
    wrap.appendChild(tile);
  });
}

function renderVenueGrid(){
  const grid = document.getElementById('venue-grid');
  if(!grid) return;
  grid.innerHTML = '';
  VENUES.forEach(v=>{
    const card = document.createElement('div');
    card.className = 'venue-card';
    const imgWrap = document.createElement('div');
    imgWrap.className = 'venue-card-img';
    imgWrap.style.background = v.gradient;
    imgWrap.appendChild(venuePhotoImg(v));
    const iconSpan = document.createElement('span');
    iconSpan.className = 'venue-photo-icon';
    iconSpan.textContent = v.icon;
    imgWrap.appendChild(iconSpan);
    card.appendChild(imgWrap);
    const body = document.createElement('div');
    body.className = 'venue-card-body';
    body.innerHTML = `<h3>${v.title}</h3><p>${v.desc.length > 90 ? v.desc.slice(0,90) + '…' : v.desc}</p><span class="venue-card-tap">Tap to explore</span>`;
    card.appendChild(body);
    card.addEventListener('click', ()=>openVenueModal(v.id));
    grid.appendChild(card);
  });
}

function openVenueModal(id){
  const v = VENUES.find(x=>x.id===id);
  if(!v) return;
  const hero = document.getElementById('venue-hero');
  hero.style.background = v.gradient;
  hero.querySelectorAll('.venue-photo').forEach(el=>el.remove());
  hero.insertBefore(venuePhotoImg(v), hero.firstChild);
  document.getElementById('venue-hero-icon').textContent = v.icon;
  document.getElementById('venue-title').textContent = v.title;
  document.getElementById('venue-desc').textContent = v.desc;
  document.getElementById('venue-overlay').classList.add('open');
}
document.getElementById('venue-close').addEventListener('click', ()=>{
  document.getElementById('venue-overlay').classList.remove('open');
});
document.getElementById('venue-overlay').addEventListener('click', (e)=>{
  if(e.target.id === 'venue-overlay') document.getElementById('venue-overlay').classList.remove('open');
});
document.getElementById('cta-explore-gallery').addEventListener('click', ()=>showView('gallery'));

/* ===================== NOTIFICATIONS ===================== */
function renderNotifications(){
  const list = document.getElementById('notifications-list');
  if(!list) return;
  list.innerHTML = '';
  const items = [];
  ANNOUNCEMENTS.forEach(a=>items.push({icon:a.icon, title:a.title, sub:a.date}));
  if(currentUser){
    currentUser.borrowed.forEach(id=>{
      const book = BOOKS.find(b=>b.id===id);
      if(book) items.push({icon:'⏰', title:'"' + book.title + '" is due soon', sub:'Return or renew from My Books'});
    });
  }
  if(items.length === 0){
    list.innerHTML = '<div class="empty-state">You\'re all caught up. No notifications right now.</div>';
    return;
  }
  items.forEach(it=>{
    const row = document.createElement('div');
    row.className = 'notif-item';
    row.innerHTML = `<div class="ic">${it.icon}</div><div><h4>${it.title}</h4><span>${it.sub}</span></div>`;
    list.appendChild(row);
  });
}

/* ===================== HISTORY LOGS ===================== */
function renderHistory(){
  const list = document.getElementById('history-list');
  if(!list) return;
  list.innerHTML = '';
  if(!currentUser || currentUser.history.length === 0){
    list.innerHTML = '<div class="empty-state">No borrow or return activity yet.</div>';
    return;
  }
  currentUser.history.forEach(h=>{
    const row = document.createElement('div');
    row.className = 'history-item';
    const tagClass = h.type === 'Borrowed' ? 'borrowed' : 'returned';
    row.innerHTML = `<div class="ic">${h.type==='Borrowed'?'📗':'📘'}</div><div><h4><span class="tag ${tagClass}">${h.type}</span>${h.title}</h4><span>${h.when}</span></div>`;
    list.appendChild(row);
  });
}

/* ===================== SAVED BOOKS ===================== */
function renderSaved(){
  const list = document.getElementById('saved-list');
  if(!list) return;
  list.innerHTML = '';
  if(!currentUser || currentUser.saved.length === 0){
    list.innerHTML = '<div class="empty-state">Nothing saved yet. Tap the ♡ on any book to bookmark it.</div>';
    return;
  }
  currentUser.saved.forEach(id=>{
    const book = BOOKS.find(b=>b.id===id);
    if(!book) return;
    const row = document.createElement('div');
    row.className = 'my-book-row';
    row.appendChild(coverEl(book));
    const info = document.createElement('div');
    info.className = 'info';
    info.innerHTML = `<h4>${book.title}</h4><span>${book.author} · ${book.category}</span>`;
    row.appendChild(info);
    const btn = document.createElement('button');
    btn.className = 'return-btn';
    btn.textContent = 'Remove';
    btn.addEventListener('click', ()=>toggleSave(book.id));
    row.appendChild(btn);
    list.appendChild(row);
  });
}

/* ===================== LIBRARIAN DASHBOARD ===================== */
function getReaderUsers(){
  return USERS.filter(u=>u.role !== 'Librarian');
}

function renderLibDashboard(){
  if(!currentUser || currentUser.role !== 'Librarian') return;
  renderLibGreeting();
  renderLibStats();
  renderLibRequests();
  renderLibBorrowers();
  renderLibTransactions();
  renderLibInventory();
  renderLibReports();
  renderLibCalendar();
}

function renderLibGreeting(){
  const el = document.getElementById('lib-greeting');
  if(!el) return;
  const hour = new Date().getHours();
  const greetWord = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';
  el.innerHTML = '👋 ' + greetWord + ', ' + currentUser.name.split(' ')[0] + '!';
}

function renderLibStats(){
  const grid = document.getElementById('lib-stats-grid');
  if(!grid) return;
  const totalCopies = BOOKS.reduce((s,b)=>s+b.copies,0);
  const totalAvailable = BOOKS.reduce((s,b)=>s+b.available,0);
  const todayStart = new Date(); todayStart.setHours(0,0,0,0);
  let borrowedToday = 0, overdue = 0;
  getReaderUsers().forEach(u=>{
    (u.history||[]).forEach(h=>{
      if(h.type==='Borrowed' && h.ts >= todayStart.getTime()) borrowedToday++;
    });
    (u.borrowed||[]).forEach(bookId=>{
      const entry = (u.history||[]).find(h=>h.type==='Borrowed' && h.bookId===bookId);
      if(entry && (Date.now() - entry.ts) > 14*86400000) overdue++;
    });
  });
  const cards = [
    {num: BOOKS.length, lbl:'Titles in Catalog'},
    {num: totalCopies, lbl:'Total Copies'},
    {num: totalAvailable, lbl:'Available Now'},
    {num: getReaderUsers().length, lbl:'Registered Members'},
    {num: borrowedToday, lbl:'Borrowed Today'},
    {num: overdue, lbl:'Overdue Items', warn:true}
  ];
  grid.innerHTML = cards.map(c=>`<div class="lib-stat-card${c.warn?' warn':''}"><div class="num">${c.num}</div><div class="lbl">${c.lbl}</div></div>`).join('');
}

function renderLibRequests(){
  const list = document.getElementById('lib-requests-list');
  if(!list) return;
  if(BORROW_REQUESTS.length === 0){
    list.innerHTML = '<div class="empty-state">No pending borrow requests.</div>';
    return;
  }
  list.innerHTML = '';
  BORROW_REQUESTS.forEach(req=>{
    const row = document.createElement('div');
    row.className = 'lib-request-row';
    row.innerHTML = `
      <div class="who">${req.member} <span class="email-tag">${req.email}</span></div>
      <div class="what">requested "${req.book}" — ${req.requested}</div>
      <div class="lib-request-actions">
        <button class="lib-req-btn lib-req-approve">Approve</button>
        <button class="lib-req-btn lib-req-deny">Deny</button>
      </div>`;
    row.querySelector('.lib-req-approve').addEventListener('click', ()=>{
      BORROW_REQUESTS = BORROW_REQUESTS.filter(r=>r.id!==req.id);
      SEED_TRANSACTIONS.unshift({type:'Borrowed', title:req.book, member:req.member, email:req.email, ts:Date.now()});
      toast('Approved ' + req.member + '\'s request for "' + req.book + '".');
      renderLibRequests();
      renderLibTransactions();
    });
    row.querySelector('.lib-req-deny').addEventListener('click', ()=>{
      BORROW_REQUESTS = BORROW_REQUESTS.filter(r=>r.id!==req.id);
      toast('Denied request from ' + req.member + '.');
      renderLibRequests();
    });
    list.appendChild(row);
  });
}

function renderLibBorrowers(){
  const list = document.getElementById('lib-borrowers-list');
  if(!list) return;
  let rows = [];
  getReaderUsers().forEach(u=>{
    (u.borrowed||[]).forEach(bookId=>{
      const book = BOOKS.find(b=>b.id===bookId);
      if(!book) return;
      const entry = (u.history||[]).find(h=>h.type==='Borrowed' && h.bookId===bookId);
      const borrowTs = entry ? entry.ts : Date.now();
      const dueTs = borrowTs + 14*86400000;
      const daysLeft = Math.ceil((dueTs - Date.now()) / 86400000);
      let status;
      if(daysLeft > 1) status = 'Due in ' + daysLeft + ' days';
      else if(daysLeft === 1) status = 'Due Tomorrow';
      else if(daysLeft === 0) status = 'Due Today';
      else status = 'Overdue by ' + Math.abs(daysLeft) + ' days';
      rows.push({name:u.name, email:u.email, title:book.title, status, overdue: daysLeft < 0});
    });
  });
  if(rows.length === 0){
    list.innerHTML = '<div class="empty-state">No members currently have a book checked out.</div>';
    return;
  }
  list.innerHTML = rows.map(r=>`
    <div class="lib-txn-row">
      <div class="what"><b>${r.name}</b> <span class="email-tag">${r.email}</span> — "${r.title}"</div>
      <div class="when" style="${r.overdue?'color:#c94a4a;font-weight:700;':''}">${r.status}</div>
    </div>`).join('');
}

function getAllTransactions(){
  let real = [];
  getReaderUsers().forEach(u=>{
    (u.history||[]).forEach(h=>real.push({type:h.type, title:h.title, member:u.name, email:u.email, ts:h.ts}));
  });
  return [...real, ...SEED_TRANSACTIONS].sort((a,b)=>b.ts-a.ts).slice(0,8);
}

function renderLibTransactions(){
  const list = document.getElementById('lib-transactions-list');
  if(!list) return;
  const txns = getAllTransactions();
  if(txns.length === 0){
    list.innerHTML = '<div class="empty-state">No transactions yet.</div>';
    return;
  }
  list.innerHTML = txns.map(t=>`
    <div class="lib-txn-row">
      <span class="tag ${t.type==='Borrowed'?'borrowed':'returned'}">${t.type}</span>
      <div class="what">${t.title} — ${t.member} <span class="email-tag">${t.email || ''}</span></div>
      <div class="when">${new Date(t.ts).toLocaleString()}</div>
    </div>`).join('');
}

function renderLibInventory(){
  const wrap = document.getElementById('lib-inventory-overview');
  if(!wrap) return;
  let html = '';
  CATEGORIES.forEach(cat=>{
    const inCat = BOOKS.filter(b=>b.category===cat);
    const copies = inCat.reduce((s,b)=>s+b.copies,0);
    const available = inCat.reduce((s,b)=>s+b.available,0);
    const pct = copies ? Math.round((available/copies)*100) : 0;
    html += `<div class="lib-inv-row">
      <div class="lib-inv-label">${cat}</div>
      <div class="lib-inv-bar-track"><div class="lib-inv-bar-fill" style="width:${pct}%;"></div></div>
      <div class="lib-inv-count">${available}/${copies}</div>
    </div>`;
  });
  const lowStock = BOOKS.filter(b=>b.available===0);
  if(lowStock.length){
    html += `<div class="lib-lowstock">⚠ ${lowStock.length} title${lowStock.length>1?'s':''} fully checked out: ${lowStock.map(b=>b.title).join(', ')}</div>`;
  }
  wrap.innerHTML = html;
}

function renderLibReports(){
  const grid = document.getElementById('lib-reports-grid');
  if(!grid) return;
  grid.innerHTML = '';
  REPORTS.forEach(r=>{
    const card = document.createElement('div');
    card.className = 'lib-report-card';
    card.innerHTML = `<h3>${r.title}</h3><p>${r.desc}</p><button>View Report</button>`;
    card.querySelector('button').addEventListener('click', ()=>openReportModal(r.id));
    grid.appendChild(card);
  });
}

function openReportModal(id){
  const report = REPORTS.find(r=>r.id===id);
  if(!report) return;
  let body = '';
  if(id === 'category'){
    body = CATEGORIES.map(cat=>{
      const inCat = BOOKS.filter(b=>b.category===cat);
      const copies = inCat.reduce((s,b)=>s+b.copies,0);
      const available = inCat.reduce((s,b)=>s+b.available,0);
      return cat + ': ' + available + ' available / ' + copies + ' total';
    }).join('\n');
  } else if(id === 'overdue'){
    let lines = [];
    getReaderUsers().forEach(u=>{
      (u.borrowed||[]).forEach(bookId=>{
        const book = BOOKS.find(b=>b.id===bookId);
        const entry = (u.history||[]).find(h=>h.type==='Borrowed' && h.bookId===bookId);
        if(book && entry && (Date.now()-entry.ts) > 14*86400000){
          lines.push(u.name + ' — "' + book.title + '"');
        }
      });
    });
    body = lines.length ? lines.join('\n') : 'No overdue items right now.';
  } else if(id === 'members'){
    const counts = {};
    getAllTransactions().forEach(t=>{ counts[t.member] = (counts[t.member]||0)+1; });
    body = Object.keys(counts).length
      ? Object.entries(counts).map(([m,c])=>m + ': ' + c + ' transaction' + (c>1?'s':'')).join('\n')
      : 'No member activity recorded yet.';
  } else if(id === 'lowstock'){
    const lowStock = BOOKS.filter(b=>b.available===0);
    body = lowStock.length ? lowStock.map(b=>b.title + ' (' + b.category + ')').join('\n') : 'No titles are fully checked out.';
  }
  document.getElementById('info-title').textContent = report.title;
  document.getElementById('info-date').textContent = 'Generated ' + new Date().toLocaleDateString();
  document.getElementById('info-body').style.whiteSpace = 'pre-line';
  document.getElementById('info-body').textContent = body;
  document.getElementById('info-overlay').classList.add('open');
}

function renderLibCalendar(){
  const wrap = document.getElementById('lib-calendar');
  if(!wrap) return;
  const now = new Date();
  const year = now.getFullYear(), month = now.getMonth();
  const monthName = now.toLocaleDateString('en-US', {month:'long', year:'numeric'});
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month+1, 0).getDate();
  const events = {3:'New Book Arrivals', 15:'Library Workshop', [daysInMonth]:'Late Fee Review'};

  let html = `<div class="lib-cal-title">${monthName}</div><div class="lib-cal-grid">`;
  ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(d=>{ html += `<div class="lib-cal-dow">${d}</div>`; });
  for(let i=0;i<firstDay;i++) html += `<div class="lib-cal-day empty"></div>`;
  for(let d=1; d<=daysInMonth; d++){
    const isToday = d === now.getDate();
    const eventName = events[d];
    html += `<div class="lib-cal-day${isToday?' today':''}${eventName?' event':''}" ${eventName?`data-event="${eventName}"`:''}>${d}${eventName?'<span class="dot"></span>':''}</div>`;
  }
  html += `</div>`;
  wrap.innerHTML = html;
  wrap.querySelectorAll('.lib-cal-day.event').forEach(el=>{
    el.addEventListener('click', ()=>toast('📅 ' + el.dataset.event));
  });
}

/* ===================== MANAGE BOOKS (Librarian) ===================== */
function renderManageBooks(){
  const wrap = document.getElementById('mb-table');
  if(!wrap) return;

  const select = document.getElementById('nbk-category');
  if(select && select.options.length === 0){
    CATEGORIES.forEach(c=>{
      const o = document.createElement('option');
      o.value = c; o.textContent = c;
      select.appendChild(o);
    });
  }

  const table = document.createElement('table');
  table.className = 'mb-table';
  table.innerHTML = `<thead><tr><th>Cover</th><th>Title</th><th>Author</th><th>Category</th><th>Copies</th><th>Available</th><th>Actions</th></tr></thead>`;
  const tbody = document.createElement('tbody');

  BOOKS.forEach(book=>{
    const tr = document.createElement('tr');
    tr.dataset.bookId = book.id;
    tr.innerHTML = `
      <td><img class="mb-cover-thumb" loading="lazy" alt="${book.title} cover" src="https://covers.openlibrary.org/b/isbn/${encodeURIComponent(book.isbn)}-S.jpg" onerror="this.style.visibility='hidden'"></td>
      <td>${book.title}</td>
      <td>${book.author}</td>
      <td>${book.category}</td>
      <td class="mb-copies-cell">${book.copies}</td>
      <td class="mb-available-cell">${book.available}</td>
      <td class="mb-actions-cell">
        <button class="mb-action-btn mb-edit">Edit</button>
        <button class="mb-action-btn mb-delete">Delete</button>
      </td>`;
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  wrap.innerHTML = '';
  wrap.appendChild(table);

  wrap.querySelectorAll('.mb-edit').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      const tr = e.target.closest('tr');
      const id = Number(tr.dataset.bookId);
      const book = BOOKS.find(b=>b.id===id);
      if(!book) return;
      tr.querySelector('.mb-copies-cell').innerHTML = `<input type="number" min="0" value="${book.copies}" class="mb-copies-input">`;
      tr.querySelector('.mb-available-cell').innerHTML = `<input type="number" min="0" value="${book.available}" class="mb-available-input">`;
      btn.textContent = 'Save';
      btn.classList.remove('mb-edit');
      btn.classList.add('mb-save');
      btn.replaceWith(btn.cloneNode(true));
      const saveBtn = tr.querySelector('.mb-save');
      saveBtn.addEventListener('click', ()=>{
        const newCopies = parseInt(tr.querySelector('.mb-copies-input').value, 10) || 0;
        let newAvailable = parseInt(tr.querySelector('.mb-available-input').value, 10) || 0;
        if(newAvailable > newCopies) newAvailable = newCopies;
        book.copies = newCopies;
        book.available = newAvailable;
        persistBooks();
        toast('Updated "' + book.title + '".');
        renderManageBooks();
        renderAllBooks();
        renderFeatured();
      });
    });
  });

  wrap.querySelectorAll('.mb-delete').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      const tr = e.target.closest('tr');
      const id = Number(tr.dataset.bookId);
      if(!btn.classList.contains('confirming')){
        btn.classList.add('confirming');
        btn.textContent = 'Confirm?';
        setTimeout(()=>{
          if(btn.classList.contains('confirming')){
            btn.classList.remove('confirming');
            btn.textContent = 'Delete';
          }
        }, 3000);
        return;
      }
      const idx = BOOKS.findIndex(b=>b.id===id);
      if(idx !== -1){
        const removed = BOOKS.splice(idx,1)[0];
        persistBooks();
        toast('Deleted "' + removed.title + '".');
      }
      renderManageBooks();
      renderAllBooks();
      renderFeatured();
      populateCategoryGrid();
    });
  });
}

document.getElementById('lib-action-add').addEventListener('click', ()=>{
  showView('managebooks');
  const form = document.getElementById('mb-add-form');
  if(form) form.style.display = 'block';
});
document.getElementById('lib-action-manage').addEventListener('click', ()=>showView('managebooks'));
document.getElementById('lib-action-reports').addEventListener('click', ()=>{
  document.getElementById('lib-reports-section').scrollIntoView({behavior:'smooth', block:'start'});
});
document.getElementById('lib-action-calendar').addEventListener('click', ()=>{
  document.getElementById('lib-calendar-section').scrollIntoView({behavior:'smooth', block:'start'});
});

document.getElementById('mb-add-toggle').addEventListener('click', ()=>{
  const form = document.getElementById('mb-add-form');
  form.style.display = form.style.display === 'none' ? 'block' : 'none';
});
document.getElementById('mb-cancel-new').addEventListener('click', ()=>{
  document.getElementById('mb-add-form').style.display = 'none';
});
document.getElementById('mb-save-new').addEventListener('click', ()=>{
  const title = document.getElementById('nbk-title').value.trim();
  const author = document.getElementById('nbk-author').value.trim();
  const category = document.getElementById('nbk-category').value;
  const date = document.getElementById('nbk-date').value.trim();
  const publisher = document.getElementById('nbk-publisher').value.trim();
  const isbn = document.getElementById('nbk-isbn').value.trim();
  const copies = parseInt(document.getElementById('nbk-copies').value, 10) || 1;
  const msg = document.getElementById('mb-msg');
  if(!title || !author || !category || !date || !publisher || !isbn){
    msg.className = 'msg err'; msg.textContent = 'Please fill in every field.'; return;
  }
  const newId = BOOKS.length ? Math.max(...BOOKS.map(b=>b.id)) + 1 : 1;
  BOOKS.push({
    id:newId,
    title: escapeHtml(title),
    author: escapeHtml(author),
    category,
    date: escapeHtml(date),
    publisher: escapeHtml(publisher),
    isbn: escapeHtml(isbn),
    copies,
    available:copies
  });
  persistBooks();
  msg.textContent = '';
  ['nbk-title','nbk-author','nbk-date','nbk-publisher','nbk-isbn'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('nbk-copies').value = 1;
  document.getElementById('mb-add-form').style.display = 'none';
  toast('Added "' + title + '" to the catalog.');
  renderManageBooks();
  renderAllBooks();
  renderFeatured();
  populateCategoryGrid();
});

/* ===================== MY BOOKS VIEW ===================== */
function renderMyBooks(){
  const list = document.getElementById('mybooks-list');
  list.innerHTML = '';
  if(!currentUser || currentUser.borrowed.length === 0){
    list.innerHTML = '<div class="empty-state">You haven\'t borrowed any books yet. Head to the Books page to find something to read.</div>';
    return;
  }
  currentUser.borrowed.forEach(id=>{
    const book = BOOKS.find(b=>b.id===id);
    if(!book) return;
    const row = document.createElement('div');
    row.className = 'my-book-row';
    const cov = coverEl(book);
    row.appendChild(cov);
    const info = document.createElement('div');
    info.className = 'info';
    info.innerHTML = `<h4>${book.title}</h4><span>${book.author} · ${book.category}</span>`;
    row.appendChild(info);
    const btn = document.createElement('button');
    btn.className = 'return-btn';
    btn.textContent = 'Return';
    btn.addEventListener('click', ()=>returnBook(book.id));
    row.appendChild(btn);
    list.appendChild(row);
  });
}

/* ===================== MY PROFILE ===================== */
function renderProfile(){
  if(!currentUser) return;
  document.getElementById('profile-avatar').textContent = currentUser.name.trim().charAt(0).toUpperCase();
  document.getElementById('profile-name').textContent = currentUser.name;
  document.getElementById('profile-email').textContent = currentUser.email;
  const joined = currentUser.joinedAt ? new Date(currentUser.joinedAt).toLocaleDateString('en-US',{month:'long', year:'numeric'}) : 'Recently';
  document.getElementById('profile-joined').textContent = 'Member since ' + joined;
  document.getElementById('profile-gender').textContent = currentUser.gender || 'Not set';
  document.getElementById('profile-birthday').textContent = currentUser.birthday
    ? new Date(currentUser.birthday + 'T00:00:00').toLocaleDateString('en-US',{month:'long', day:'numeric', year:'numeric'})
    : 'Not set';

  document.getElementById('profile-stats').innerHTML = `
    <div><div class="num">${currentUser.borrowed.length}</div><div class="lbl">Borrowed</div></div>
    <div><div class="num">${currentUser.saved.length}</div><div class="lbl">Saved</div></div>
    <div><div class="num">${currentUser.history.length}</div><div class="lbl">History Entries</div></div>`;

  document.getElementById('profile-view-mode').style.display = 'block';
  document.getElementById('profile-edit-mode').style.display = 'none';
  document.getElementById('profile-msg').textContent = '';
}

document.getElementById('profile-edit-btn').addEventListener('click', ()=>{
  document.getElementById('pf-name').value = currentUser.name;
  document.getElementById('pf-gender').value = currentUser.gender || '';
  document.getElementById('pf-birthday').value = currentUser.birthday || '';
  document.getElementById('profile-view-mode').style.display = 'none';
  document.getElementById('profile-edit-mode').style.display = 'block';
});
document.getElementById('profile-cancel-btn').addEventListener('click', ()=>{
  renderProfile();
});
document.getElementById('contact-send-btn').addEventListener('click', ()=>{
  const name = document.getElementById('contact-name').value.trim();
  const email = document.getElementById('contact-email').value.trim();
  const message = document.getElementById('contact-message').value.trim();
  const msg = document.getElementById('contact-msg');
  if(!name || !email || !message){
    msg.className = 'msg err'; msg.textContent = 'Please fill in every field.'; return;
  }
  if(!/^\S+@\S+\.\S+$/.test(email)){
    msg.className = 'msg err'; msg.textContent = 'Please enter a valid email address.'; return;
  }
  msg.className = 'msg ok'; msg.textContent = "Thanks! We'll get back to you soon.";
  document.getElementById('contact-name').value = '';
  document.getElementById('contact-email').value = '';
  document.getElementById('contact-message').value = '';
  toast('Message sent to Library Link support.');
});
document.getElementById('profile-save-btn').addEventListener('click', ()=>{
  const name = document.getElementById('pf-name').value.trim();
  const gender = document.getElementById('pf-gender').value;
  const birthday = document.getElementById('pf-birthday').value;
  const msg = document.getElementById('profile-msg');
  if(!name){
    msg.className = 'msg err'; msg.textContent = 'Name cannot be empty.'; return;
  }
  currentUser.name = escapeHtml(name);
  currentUser.gender = gender;
  currentUser.birthday = birthday;
  persistUsers();
  renderNav();
  renderProfile();
  toast('Profile updated.');
});

/* ===================== DATA EXPORT / IMPORT ===================== */
document.getElementById('data-export-btn').addEventListener('click', ()=>{
  const backup = {
    exportedAt: new Date().toISOString(),
    books: BOOKS,
    users: USERS
  };
  const blob = new Blob([JSON.stringify(backup, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'librarylink-backup.json';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  toast('Backup downloaded.');
});

document.getElementById('data-import-btn').addEventListener('click', ()=>{
  document.getElementById('data-import-file').click();
});

document.getElementById('data-import-file').addEventListener('change', (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const msg = document.getElementById('data-io-msg');
  const reader = new FileReader();
  reader.onload = () => {
    try{
      const parsed = JSON.parse(reader.result);
      if(!Array.isArray(parsed.books) || !Array.isArray(parsed.users)){
        throw new Error('Invalid backup file.');
      }
      BOOKS = parsed.books;
      USERS = parsed.users;
      const stillExists = currentUser ? USERS.find(u=>u.email === currentUser.email) : null;
      currentUser = stillExists || null;
      persistBooks();
      persistUsers();
      persistSession(currentUser ? currentUser.email : null);
      populateCategoryGrid();
      renderNav();
      renderFeatured();
      renderAllBooks();
      renderAnnouncements();
      renderHomeGalleryPreview();
      showView('home');
      msg.className = 'msg ok';
      msg.textContent = 'Backup restored successfully.';
      toast('Backup restored.');
    } catch(err){
      msg.className = 'msg err';
      msg.textContent = 'Could not read that file. Make sure it\'s a Library Link backup.';
    }
    e.target.value = '';
  };
  reader.readAsText(file);
});

/* ===================== SEARCH WIRING ===================== */
function goToBooksWithFilters(query, cat){
  document.getElementById('books-search').value = query || '';
  document.getElementById('books-category').value = cat || '';
  showView('books');
  renderAllBooks();
}
document.getElementById('cta-browse').addEventListener('click', ()=>goToBooksWithFilters('',''));
document.getElementById('cta-view-more').addEventListener('click', ()=>goToBooksWithFilters('',''));
document.getElementById('member-browse-btn').addEventListener('click', ()=>goToBooksWithFilters('',''));
document.getElementById('member-borrow-btn').addEventListener('click', ()=>goToBooksWithFilters('',''));
document.getElementById('member-history-btn').addEventListener('click', ()=>showView('history'));
document.getElementById('cta-view-all-activity').addEventListener('click', ()=>showView('history'));
document.getElementById('global-borrow-now-btn').addEventListener('click', ()=>{
  if(selectedBookIds.length === 0) return;
  if(!currentUser){ showView('role'); toast('Please sign in to borrow books.'); return; }
  let successTitles = [];
  let failMessages = [];
  selectedBookIds.slice().forEach(id=>{
    const book = BOOKS.find(b=>b.id===id);
    if(!book) return;
    if(currentUser.borrowed.includes(book.id)){ failMessages.push(book.title + ' (already borrowed)'); return; }
    const result = borrowBookCore(id);
    if(result.ok) successTitles.push(result.book.title);
    else if(result.reason === 'unavailable') failMessages.push(book.title + ' (no copies left)');
    else if(result.reason === 'category-limit') failMessages.push(book.title + ' (category limit)');
  });
  selectedBookIds = [];
  renderNav();
  renderFeatured();
  renderAllBooks();
  if(successTitles.length && failMessages.length === 0){
    toast('Borrowed ' + successTitles.length + (successTitles.length > 1 ? ' books.' : ' book: "' + successTitles[0] + '".'));
  } else if(successTitles.length && failMessages.length){
    toast('Borrowed ' + successTitles.length + ', skipped ' + failMessages.length + '.');
  } else {
    toast('Could not borrow the selected book' + (failMessages.length > 1 ? 's' : '') + '.');
  }
});
document.getElementById('books-search').addEventListener('input', renderAllBooks);
document.getElementById('books-category').addEventListener('change', renderAllBooks);

document.getElementById('cta-get-started').addEventListener('click', ()=>{
  showView(currentUser ? 'books' : 'role');
});

/* ===================== AUTH LOGIC ===================== */
function chooseRole(role){
  selectedRole = role;
  renderRoleBadges();
  showView('signin');
}
document.getElementById('role-reader').addEventListener('click', ()=>chooseRole('Reader'));
document.getElementById('role-librarian').addEventListener('click', ()=>chooseRole('Librarian'));

function renderRoleBadges(){
  if(!selectedRole) selectedRole = 'Reader';
  const icon = selectedRole === 'Librarian' ? '🗂' : '📖';
  const html = icon + ' Role: <b>' + selectedRole + '</b> &nbsp;<a class="role-change-link">Change</a>';
  ['si-role-badge','rg-role-badge'].forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.innerHTML = html;
  });
  document.querySelectorAll('.role-change-link').forEach(a=>{
    a.addEventListener('click', ()=>showView('role'));
  });
}

function initRoleSelection(){
  const reader = document.getElementById('role-reader');
  const librarian = document.getElementById('role-librarian');
  // Wire the Continue buttons specifically
  if(reader){
    const btn = reader.querySelector('.role-continue-btn');
    if(btn) btn.addEventListener('click', (e)=>{ e.stopPropagation(); chooseRole('Reader'); });
    reader.addEventListener('click', ()=>{
      // highlight selected option but don't navigate until Continue
      document.querySelectorAll('.role-option').forEach(o=>o.classList.toggle('selected', o===reader));
      selectedRole = 'Reader';
    });
  }
  if(librarian){
    const btn = librarian.querySelector('.role-continue-btn');
    if(btn) btn.addEventListener('click', (e)=>{ e.stopPropagation(); chooseRole('Librarian'); });
    librarian.addEventListener('click', ()=>{
      document.querySelectorAll('.role-option').forEach(o=>o.classList.toggle('selected', o===librarian));
      selectedRole = 'Librarian';
    });
  }
}

/* Handle Supabase OAuth redirect results */
async function handleSupabaseAuthRedirect(){
  if(!window.supabase || !window.supabase.auth || typeof window.supabase.auth.getSessionFromUrl !== 'function') return;
  try{
    const { data, error } = await window.supabase.auth.getSessionFromUrl({ storeSession: true });
    if(error) return;
    const session = data && data.session;
    if(!session || !session.user) return;
    const email = session.user.email;
    const found = USERS.find(u=>u.email === email);
    if(found){
      currentUser = found;
      persistSession(email);
      renderNav();
      showView('home');
      toast('Signed in with Google.');
      return;
    }
    // No local account: auto-create a local user from the Google profile
    const metadata = session.user.user_metadata || {};
    const displayName = metadata.full_name || metadata.name || (email ? email.split('@')[0] : 'Google User');
    const roleForNewUser = selectedRole || 'Reader';
    const newUser = {
      name: escapeHtml(displayName),
      email: email,
      role: roleForNewUser,
      gender: metadata.gender || 'Prefer not to say',
      birthday: metadata.birthday || '',
      joinedAt: Date.now(),
      password: null,
      borrowed: [],
      saved: [],
      history: []
    };
    USERS.push(newUser);
    currentUser = newUser;
    persistUsers();
    persistSession(email);
    renderNav();
    showView('home');
    toast('Account created and signed in with Google.');
  }catch(err){
    console.warn('OAuth redirect handling error', err);
  }
}

function setEyeToggles(){
  document.querySelectorAll('[data-toggle]').forEach(eye=>{
    eye.addEventListener('click', ()=>{
      const f = document.getElementById(eye.getAttribute('data-toggle'));
      f.type = f.type === 'password' ? 'text' : 'password';
    });
  });
}

function doLogin(email, password){
  const msg = document.getElementById('si-msg');
  if(!email || !password){
    msg.className = 'msg err'; msg.textContent = 'Please enter both email and password.'; return;
  }
  const user = USERS.find(u=>u.email.toLowerCase() === email.toLowerCase());
  if(!user || user.password !== password){
    msg.className = 'msg err'; msg.textContent = 'Incorrect email or password.'; return;
  }
  if(selectedRole && user.role && user.role !== selectedRole){
    msg.className = 'msg err';
    msg.textContent = 'This account is registered as a ' + user.role + '. Choose "' + user.role + '" on the role screen, or use a different account.';
    return;
  }
  currentUser = user;
  persistSession(user.email);
  msg.className = 'msg ok'; msg.textContent = 'Signed in! Redirecting…';
  renderNav();
  setTimeout(()=>{
    document.getElementById('si-email').value='';
    document.getElementById('si-password').value='';
    msg.textContent='';
    showView('home');
    toast('Welcome back, ' + user.name.split(' ')[0] + '.');
  }, 500);
}
document.getElementById('si-submit').addEventListener('click', ()=>{
  doLogin(document.getElementById('si-email').value.trim(), document.getElementById('si-password').value);
});
document.getElementById('si-password').addEventListener('keydown', (e)=>{
  if(e.key==='Enter') document.getElementById('si-submit').click();
});
document.getElementById('si-google').addEventListener('click', ()=>{
  // Prefer Supabase OAuth when available
  if(window.supabase && window.supabase.auth && typeof window.supabase.auth.signInWithOAuth === 'function'){
    window.supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: window.location.href } });
    return;
  }
  // Fallback: simulate Google account sign-in
  let gUser = USERS.find(u=>u.email==='you@gmail.com');
  if(!gUser){
    gUser = {name:'Google User', email:'you@gmail.com', password:null, role: selectedRole || 'Reader', gender:'Prefer not to say', birthday:'', joinedAt:Date.now(), borrowed:[], saved:[], history:[]};
    USERS.push(gUser);
  }
  currentUser = gUser;
  persistUsers();
  persistSession(gUser.email);
  renderNav();
  showView('home');
  toast('Signed in with Google.');
});
document.getElementById('rg-google').addEventListener('click', ()=>{
  const msg = document.getElementById('rg-msg');
  // Ensure user has selected a role before Google signup
  if(!selectedRole){
    toast('Please choose a role first.');
    showView('role');
    return;
  }
  if(!document.getElementById('rg-terms').checked){
    msg.className = 'msg err';
    msg.textContent = 'Please agree to the Terms & Conditions to continue with Google.';
    return;
  }
  // Prefer Supabase OAuth when available
  if(window.supabase && window.supabase.auth && typeof window.supabase.auth.signInWithOAuth === 'function'){
    window.supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: window.location.href } });
    return;
  }
  // Fallback simulation - auto-create local account when Supabase isn't available
  const googleProfile = { name: 'Google User', email: 'you@gmail.com' };
  let gUser = USERS.find(u=>u.email === googleProfile.email);
  if(gUser){
    currentUser = gUser;
    persistSession(gUser.email);
    msg.textContent = '';
    renderNav();
    showView('home');
    toast('Signed in with Google.');
    return;
  }
  const roleForNewUser = selectedRole || 'Reader';
  const newUser = {
    name: escapeHtml(googleProfile.name),
    email: googleProfile.email,
    role: roleForNewUser,
    gender: 'Prefer not to say',
    birthday: '',
    joinedAt: Date.now(),
    password: null,
    borrowed: [],
    saved: [],
    history: []
  };
  USERS.push(newUser);
  currentUser = newUser;
  persistUsers();
  persistSession(newUser.email);
  msg.textContent = '';
  renderNav();
  showView('home');
  toast('Account created and signed in with Google.');
  return;
});
document.getElementById('si-forgot').addEventListener('click', ()=>{
  const msg = document.getElementById('si-msg');
  msg.className = 'msg ok';
  msg.textContent = 'If that email exists, a reset link has been sent.';
});

document.getElementById('rg-submit').addEventListener('click', ()=>{
  const name = document.getElementById('rg-name').value.trim();
  const email = document.getElementById('rg-email').value.trim();
  const gender = document.getElementById('rg-gender').value;
  const birthday = document.getElementById('rg-birthday').value;
  const pw = document.getElementById('rg-password').value;
  const cpw = document.getElementById('rg-confirm').value;
  const agreed = document.getElementById('rg-terms').checked;
  const msg = document.getElementById('rg-msg');
  if(!name || !email || !gender || !birthday || !pw || !cpw){
    msg.className='msg err'; msg.textContent='Please fill in every field.'; return;
  }
  if(!/^\S+@\S+\.\S+$/.test(email)){
    msg.className='msg err'; msg.textContent='Please enter a valid email address.'; return;
  }
  if(USERS.some(u=>u.email.toLowerCase()===email.toLowerCase())){
    msg.className='msg err'; msg.textContent='An account with that email already exists.'; return;
  }
  const age = Math.floor((Date.now() - new Date(birthday).getTime()) / 31557600000);
  if(age < 13){
    msg.className='msg err'; msg.textContent='You must be at least 13 years old to register.'; return;
  }
  if(pw.length < 6){
    msg.className='msg err'; msg.textContent='Password must be at least 6 characters.'; return;
  }
  if(pw !== cpw){
    msg.className='msg err'; msg.textContent='Passwords do not match.'; return;
  }
  if(!agreed){
    msg.className='msg err'; msg.textContent='Please agree to the Terms & Conditions to continue.'; return;
  }
  const user = {name: escapeHtml(name), email, role: selectedRole || 'Reader', gender, birthday, joinedAt:Date.now(), password: pw, borrowed:[], saved:[], history:[]};
  USERS.push(user);
  currentUser = user;
  persistUsers();
  persistSession(user.email);
  msg.className='msg ok'; msg.textContent='Account created! Redirecting…';
  renderNav();
  setTimeout(()=>{
    ['rg-name','rg-email','rg-password','rg-confirm','rg-birthday'].forEach(id=>document.getElementById(id).value='');
    document.getElementById('rg-gender').value = '';
    document.getElementById('rg-terms').checked = false;
    msg.textContent='';
    showView('home');
    toast('Welcome to Library Link, ' + name.split(' ')[0] + '.');
  }, 500);
});

/* ===================== INIT ===================== */
(async function initApp(){
  await loadPersistedState();
  populateCategorySelects();
  populateCategoryGrid();
  setEyeToggles();
  initSearchBar('hero-search', 'hero-search-results', 'hero-category');
  initSearchBar('member-search', 'member-search-results', 'member-category');
  renderNav();
  renderFeatured();
  renderAllBooks();
  renderAnnouncements();
  renderHomeGalleryPreview();
  // Handle OAuth redirect if returning from Supabase Google sign-in
  if(typeof handleSupabaseAuthRedirect === 'function') await handleSupabaseAuthRedirect();
  initRoleSelection();
  showView('home');
})();
document.getElementById('cta-create-account').addEventListener('click', ()=>showView('register'));
