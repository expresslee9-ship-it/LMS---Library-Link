/* ===================== LIBRARY GALLERY ===================== */
function venuePhotoImg(venue){
  const img = document.createElement('img');
  img.className = 'venue-photo';
  img.loading = 'lazy';
  img.alt = venue.title;
  img.src = 'https://picsum.photos/seed/' + encodeURIComponent(venue.photo) + '/500/360';
  img.addEventListener('error', ()=>img.remove());
  img.addEventListener('load', ()=>{ if(img.naturalWidth < 10) img.remove(); });
  return img;
}

function renderHomeGalleryPreview(){
  const wrap = document.getElementById('home-gallery-preview');
  if(!wrap) return;
  wrap.innerHTML = '';
  VENUES.slice(0,4).forEach(v=>{
    const tile = document.createElement('div');
    tile.className = 'gallery-tile';
    tile.style.background = v.gradient;
    tile.appendChild(venuePhotoImg(v));
    const scrim = document.createElement('div');
    scrim.className = 'venue-scrim';
    tile.appendChild(scrim);
    const label = document.createElement('span');
    label.className = 'tile-label';
    label.textContent = v.title;
    tile.appendChild(label);
    tile.addEventListener('click', ()=>openVenueModal(v.id));
    wrap.appendChild(tile);
  });
}

function renderVenueGrid(){
  const grid = document.getElementById('venue-grid');
  if(!grid) return;
  grid.innerHTML = '';
  VENUES.forEach(v=>{
    const card = document.createElement('div');
    card.className = 'venue-card';
    const imgWrap = document.createElement('div');
    imgWrap.className = 'venue-card-img';
    imgWrap.style.background = v.gradient;
    imgWrap.appendChild(venuePhotoImg(v));
    const iconSpan = document.createElement('span');
    iconSpan.className = 'venue-photo-icon';
    iconSpan.textContent = v.icon;
    imgWrap.appendChild(iconSpan);
    card.appendChild(imgWrap);
    const body = document.createElement('div');
    body.className = 'venue-card-body';
    body.innerHTML = `<h3>${v.title}</h3><p>${v.desc.length > 90 ? v.desc.slice(0,90) + '…' : v.desc}</p><span class="venue-card-tap">Tap to explore</span>`;
    card.appendChild(body);
    card.addEventListener('click', ()=>openVenueModal(v.id));
    grid.appendChild(card);
  });
}

function openVenueModal(id){
  const v = VENUES.find(x=>x.id===id);
  if(!v) return;
  const hero = document.getElementById('venue-hero');
  if(!hero) return;
  hero.style.background = v.gradient;
  hero.querySelectorAll('.venue-photo').forEach(el=>el.remove());
  hero.insertBefore(venuePhotoImg(v), hero.firstChild);
  const iconEl = document.getElementById('venue-hero-icon');
  if(iconEl) iconEl.textContent = v.icon;
  const titleEl = document.getElementById('venue-title');
  if(titleEl) titleEl.textContent = v.title;
  const descEl = document.getElementById('venue-desc');
  if(descEl) descEl.textContent = v.desc;
  const overlay = document.getElementById('venue-overlay');
  if(overlay) overlay.classList.add('open');
}

const venueClose = document.getElementById('venue-close');
if(venueClose) venueClose.addEventListener('click', ()=>{
  const overlay = document.getElementById('venue-overlay');
  if(overlay) overlay.classList.remove('open');
});

const venueOverlay = document.getElementById('venue-overlay');
if(venueOverlay){
  venueOverlay.addEventListener('click', (e)=>{
    if(e.target.id === 'venue-overlay') venueOverlay.classList.remove('open');
  });
}

const ctaExploreGallery = document.getElementById('cta-explore-gallery');
if(ctaExploreGallery) ctaExploreGallery.addEventListener('click', ()=>showView('gallery'));
