let userID = null;

async function loadProfile() {

const {

data:{session}

}=await supabaseClient.auth.getSession();

if(!session){

location.href="login.html";

return;

}

userID=session.user.id;

const {

data,
error

}=await supabaseClient

.from("profiles")

.select("*")

.eq("id",userID)

.single();

if(error){

console.log(error);

return;

}

document.getElementById("studentID").value=data.student_id;
document.getElementById("fullname").value=data.full_name;
document.getElementById("email").value=data.email;
document.getElementById("course").value=data.course || "";
document.getElementById("contact").value=data.contact || "";

if(data.avatar_url){

document.getElementById("avatar").src=data.avatar_url;

}

}

loadProfile();

async function saveProfile(){

const fullname=document.getElementById("fullname").value;

const course=document.getElementById("course").value;

const contact=document.getElementById("contact").value;

const year=document.getElementById("year").value;

const {

error

}=await supabaseClient

.from("profiles")

.update({

full_name:fullname,

course:course,

contact:contact,

year_level:year

})

.eq("id",userID);

if(error){

alert(error.message);

return;

}

alert("Profile Updated!");

}

async function logout(){

await supabaseClient.auth.signOut();

location.href="login.html";

}