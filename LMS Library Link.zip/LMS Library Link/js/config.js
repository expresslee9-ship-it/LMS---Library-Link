/* ===================== SUPABASE CONFIG ===================== */
const SUPABASE_URL = "https://tbenckyoowfrfumsbojd.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRiZW5ja3lvb3dmcmZ1bXNib2pkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE1NDczNjYsImV4cCI6MjA5NzEyMzM2Nn0.j_ttHixrujNzQZr-baMHIyPxMrUhyKb8gWUE6prTm1U";
if (typeof supabase !== 'undefined') {
  if (typeof window.supabaseClient === 'undefined' || window.supabaseClient === null) {
    if (typeof supabase.createClient === 'function') {
      window.supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    } else {
      window.supabaseClient = supabase;
    }
  }
  if (!window.supabase || typeof window.supabase.auth === 'undefined') {
    window.supabase = supabase;
  }
}

const supabaseClient = window.supabaseClient || null;
/* ===================== DATA CONFIGURATION ===================== */
const CATEGORIES = ["Self-Help","Technology","Fiction","Mystery","Romance","Nonfiction"];
const COVER_COLORS = {
  "Self-Help":"linear-gradient(160deg,#c98a4b,#8a5a3c)",
  "Technology":"linear-gradient(160deg,#4a6d8c,#2f3f52)",
  "Fiction":"linear-gradient(160deg,#7a5a8c,#4a3a5c)",
  "Mystery":"linear-gradient(160deg,#3a3a3a,#1c1c1c)",
  "Romance":"linear-gradient(160deg,#c96b8a,#8a3a52)",
  "Nonfiction":"linear-gradient(160deg,#5a8a6b,#2f5c40)"
};

let BOOKS = [
  {id:1, title:"The 48 Laws of Power", author:"Robert Greene", category:"Self-Help", date:"November 1998", publisher:"Penguin Books", isbn:"0140280197", copies:3, available:3},
  {id:2, title:"Computer Concepts", author:"June Parsons & Dan Oja", category:"Technology", date:"January 2003", publisher:"Cengage Learning", isbn:"0619267619", copies:2, available:2},
  {id:3, title:"On Emerald Downs", author:"Patricia Shaw", category:"Fiction", date:"March 2007", publisher:"Hodder", isbn:"9780733622231", copies:2, available:1},
  {id:4, title:"Atomic Habits", author:"James Clear", category:"Self-Help", date:"October 2018", publisher:"Avery", isbn:"0735211299", copies:4, available:4},
  {id:5, title:"Clean Code", author:"Robert C. Martin", category:"Technology", date:"August 2008", publisher:"Prentice Hall", isbn:"0132350882", copies:2, available:0},
  {id:6, title:"The Silent Patient", author:"Alex Michaelides", category:"Mystery", date:"February 2019", publisher:"Celadon Books", isbn:"1250301696", copies:3, available:2},
  {id:7, title:"Pride and Prejudice", author:"Jane Austen", category:"Romance", date:"January 1813", publisher:"T. Egerton", isbn:"9780141439518", copies:5, available:5},
  {id:8, title:"Sapiens", author:"Yuval Noah Harari", category:"Nonfiction", date:"February 2011", publisher:"Harvill Secker", isbn:"0062316095", copies:3, available:1},
  {id:9, title:"How to Win Friends and Influence People", author:"Dale Carnegie", category:"Self-Help", date:"October 1998", publisher:"Simon & Schuster", isbn:"0671027034", copies:3, available:3},
  {id:10, title:"The Pragmatic Programmer", author:"Andrew Hunt & David Thomas", category:"Technology", date:"October 1999", publisher:"Addison-Wesley", isbn:"020161622X", copies:2, available:2},
  {id:11, title:"The Great Gatsby", author:"F. Scott Fitzgerald", category:"Fiction", date:"April 1925", publisher:"Charles Scribner's Sons", isbn:"9780743273565", copies:3, available:3},
  {id:12, title:"To Kill a Mockingbird", author:"Harper Lee", category:"Fiction", date:"July 1960", publisher:"J.B. Lippincott & Co.", isbn:"9780061120084", copies:3, available:2},
  {id:13, title:"Gone Girl", author:"Gillian Flynn", category:"Mystery", date:"June 2012", publisher:"Crown Publishing", isbn:"9780307588364", copies:2, available:2},
  {id:14, title:"And Then There Were None", author:"Agatha Christie", category:"Mystery", date:"November 1939", publisher:"Collins Crime Club", isbn:"9780062073488", copies:3, available:3},
  {id:15, title:"The Notebook", author:"Nicholas Sparks", category:"Romance", date:"October 1996", publisher:"Warner Books", isbn:"0446605236", copies:3, available:3},
  {id:16, title:"Me Before You", author:"Jojo Moyes", category:"Romance", date:"January 2012", publisher:"Penguin Books", isbn:"9780143124542", copies:2, available:1},
  {id:17, title:"Educated", author:"Tara Westover", category:"Nonfiction", date:"February 2018", publisher:"Random House", isbn:"9780399590504", copies:3, available:2},
  {id:18, title:"Outliers", author:"Malcolm Gladwell", category:"Nonfiction", date:"November 2008", publisher:"Little, Brown and Company", isbn:"9780316017930", copies:3, available:3},
  {id:19, title:"The 7 Habits of Highly Effective People", author:"Stephen R. Covey", category:"Self-Help", date:"August 1989", publisher:"Free Press", isbn:"9781982137274", copies:4, available:0},
  {id:20, title:"Think and Grow Rich", author:"Napoleon Hill", category:"Self-Help", date:"1937", publisher:"The Ralston Society", isbn:"9781585424337", copies:2, available:2},
];

let USERS = [
  {name:"Demo User", email:"demo@librarylink.com", password:"demo123", role:"Reader", gender:"Prefer not to say", birthday:"1998-05-14", joinedAt:new Date('2025-01-10').getTime(), borrowed:[], saved:[], history:[]},
  {name:"Librarian Demo", email:"librarian@librarylink.com", password:"librarian123", role:"Librarian", gender:"Prefer not to say", birthday:"1990-03-22", joinedAt:new Date('2024-08-01').getTime(), borrowed:[], saved:[], history:[]}
];

const ANNOUNCEMENTS = [
  {id:1, icon:"📢", title:"Library Schedules", date:"Updated July 1, 2026", body:"The library is open Monday through Saturday, 9 AM to 7 PM, and closed on Sundays and public holidays. Borrowed books are due 14 days after checkout unless renewed."},
  {id:2, icon:"📚", title:"New Books Available", date:"Updated June 28, 2026", body:"Fresh arrivals have landed across Fiction, Technology, and Self-Help. Head to the Books page and filter by category to see what's new on the shelf."},
  {id:3, icon:"💸", title:"Late Fees Updated", date:"Updated June 20, 2026", body:"Late fees are now $0.25 per day per title, capped at $5 per book. Return or renew on time to avoid extra charges."},
  {id:4, icon:"🏖", title:"Holiday Hours", date:"Updated June 15, 2026", body:"The library will close early at 3 PM on public holidays and remain closed the following day. Check the schedule before planning your visit."},
  {id:5, icon:"🏛", title:"New Study Rooms", date:"Updated June 10, 2026", body:"Three new private study rooms are now open on the second floor. Reserve one for up to 3 hours through the Library Services desk."}
];

const VENUES = [
  {id:1, icon:"📖", title:"Reading Hall", gradient:"linear-gradient(160deg,#c98a4b,#8a5a3c)", photo:"library-reading-hall-1", desc:"A quiet, sunlit hall lined with reading tables — the main space for individual study and leisure reading."},
  {id:2, icon:"🧑‍💻", title:"Study Pods", gradient:"linear-gradient(160deg,#4a6d8c,#2f3f52)", photo:"library-study-pods-2", desc:"Enclosed pods for focused work or small group discussions. Each pod seats up to 4 people."},
  {id:3, icon:"🧸", title:"Kids' Corner", gradient:"linear-gradient(160deg,#7a5a8c,#4a3a5c)", photo:"library-kids-corner-3", desc:"A colorful, low-shelf area stocked with picture books and early readers for young visitors."},
  {id:4, icon:"💻", title:"Digital Lab", gradient:"linear-gradient(160deg,#5a8a6b,#2f5c40)", photo:"library-digital-lab-4", desc:"Rows of public computers for catalog searches, e-book downloads, and general research."},
  {id:5, icon:"🌿", title:"Reading Garden", gradient:"linear-gradient(160deg,#7fae6a,#3f6b32)", photo:"library-reading-garden-5", desc:"An outdoor courtyard with shaded seating — a relaxed spot to read or take a break."},
  {id:6, icon:"🗄", title:"Archive Room", gradient:"linear-gradient(160deg,#9a8360,#5c4a2e)", photo:"library-archive-room-6", desc:"Home to rare editions, historical records, and reference-only materials."}
];

let BORROW_REQUESTS = [
  {id:1, member:"Jasmine Cruz", email:"jasmine.cruz@gmail.com", book:"Atomic Habits", requested:"2 hours ago"},
  {id:2, member:"Marcus Reyes", email:"marcus.reyes@gmail.com", book:"The Silent Patient", requested:"5 hours ago"}
];

const SEED_TRANSACTIONS = [
  {type:'Borrowed', title:'The 48 Laws of Power', member:'Nina Alvarez', email:'nina.alvarez@gmail.com', ts:Date.now() - 2*3600000},
  {type:'Returned', title:'On Emerald Downs', member:'Carlo Dizon', email:'carlo.dizon@gmail.com', ts:Date.now() - 6*3600000}
];

const REPORTS = [
  {id:'category', title:'Category Breakdown Report', desc:'Copies and availability across every category.'},
  {id:'overdue', title:'Overdue Items Report', desc:'Members currently holding an overdue title.'},
  {id:'members', title:'Member Activity Report', desc:'Borrow and return counts by member.'},
  {id:'lowstock', title:'Low Stock Report', desc:'Titles with zero copies currently available.'}
];

// Persistence & State
const STORAGE_BOOKS_KEY = 'librarylink-books';
const STORAGE_USERS_KEY = 'librarylink-users';
const STORAGE_SESSION_KEY = 'librarylink-session';

let currentUser = null;
let selectedRole = null;
let selectedBookIds = [];
let activeModalBookId = null;
const annTimers = {};