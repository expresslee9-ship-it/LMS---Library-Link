/* ===================== NOTIFICATIONS / HISTORY / SAVED ===================== */
function renderNotifications(){
  const list = document.getElementById('notifications-list');
  if(!list) return;
  list.innerHTML = '';
  const items = [];
  ANNOUNCEMENTS.forEach(a=>items.push({icon:a.icon, title:a.title, sub:a.date}));
  if(currentUser){
    currentUser.borrowed.forEach(id=>{
      const book = BOOKS.find(b=>b.id===id);
      if(book) items.push({icon:'⏰', title:'"' + book.title + '" is due soon', sub:'Return or renew from My Books'});
    });
  }
  if(items.length === 0){
    list.innerHTML = '<div class="empty-state">You\'re all caught up. No notifications right now.</div>';
    return;
  }
  items.forEach(it=>{
    const row = document.createElement('div');
    row.className = 'notif-item';
    row.innerHTML = `<div class="ic">${it.icon}</div><div><h4>${it.title}</h4><span>${it.sub}</span></div>`;
    list.appendChild(row);
  });
}

function renderHistory(){
  const list = document.getElementById('history-list');
  if(!list) return;
  list.innerHTML = '';
  if(!currentUser || currentUser.history.length === 0){
    list.innerHTML = '<div class="empty-state">No borrow or return activity yet.</div>';
    return;
  }
  currentUser.history.forEach(h=>{
    const row = document.createElement('div');
    row.className = 'history-item';
    const tagClass = h.type === 'Borrowed' ? 'borrowed' : 'returned';
    row.innerHTML = `<div class="ic">${h.type==='Borrowed'?'📗':'📘'}</div><div><h4><span class="tag ${tagClass}">${h.type}</span>${h.title}</h4><span>${h.when}</span></div>`;
    list.appendChild(row);
  });
}

function renderSaved(){
  const list = document.getElementById('saved-list');
  if(!list) return;
  list.innerHTML = '';
  if(!currentUser || currentUser.saved.length === 0){
    list.innerHTML = '<div class="empty-state">Nothing saved yet. Tap the ♡ on any book to bookmark it.</div>';
    return;
  }
  currentUser.saved.forEach(id=>{
    const book = BOOKS.find(b=>b.id===id);
    if(!book) return;
    const row = document.createElement('div');
    row.className = 'my-book-row';
    row.appendChild(coverEl(book));
    const info = document.createElement('div');
    info.className = 'info';
    info.innerHTML = `<h4>${book.title}</h4><span>${book.author} · ${book.category}</span>`;
    row.appendChild(info);
    const btn = document.createElement('button');
    btn.className = 'return-btn';
    btn.textContent = 'Remove';
    btn.addEventListener('click', ()=>toggleSave(book.id));
    row.appendChild(btn);
    list.appendChild(row);
  });
}
