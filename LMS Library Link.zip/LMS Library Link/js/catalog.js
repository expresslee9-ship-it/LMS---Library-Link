async function loadBooks() {

const grid=document.getElementById("bookGrid");

grid.innerHTML="Loading books...";

const {data,error}=await supabaseClient

.from("books")

.select("*");

if(error){

grid.innerHTML="Unable to load books.";

return;

}

grid.innerHTML="";

data.forEach(book=>{

grid.innerHTML+=`

<div class="book">

<img src="${book.cover_url || 'assets/images/default-book.png'}">

<h4>${book.title}</h4>

<p>

Available :

${book.available}

</p>

<button onclick="borrowBook(${book.id})">

Borrow

</button>

</div>

`;

});

}

loadBooks();



async function borrowBook(id){

const {

data:{session}

}=await supabaseClient.auth.getSession();

if(!session){

alert("Please login.");

return;

}

const due=new Date();

due.setDate(due.getDate()+7);

const {

error

}=await supabaseClient

.from("borrow_records")

.insert({

user_id:session.user.id,

book_id:id,

due_date:due.toISOString().split("T")[0]

});

if(error){

alert(error.message);

return;

}

alert("Book borrowed successfully!");

location.reload();

}



document.getElementById("searchBook")

.addEventListener("keyup",function(){

const keyword=this.value.toLowerCase();

const books=document.querySelectorAll(".book");

books.forEach(book=>{

book.style.display=

book.innerText.toLowerCase().includes(keyword)

?

"block"

:

"none";

});

});