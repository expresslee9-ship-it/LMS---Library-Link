/* ===================== LIBRARIAN DASHBOARD / MANAGE BOOKS ===================== */
function getReaderUsers(){
  return USERS.filter(u=>u.role !== 'Librarian');
}

function renderLibDashboard(){
  if(!currentUser || currentUser.role !== 'Librarian') return;
  renderLibGreeting();
  renderLibStats();
  renderLibRequests();
  renderLibBorrowers();
  renderLibTransactions();
  renderLibInventory();
  renderLibReports();
  renderLibCalendar();
}

function renderLibGreeting(){
  const el = document.getElementById('lib-greeting');
  if(!el) return;
  const hour = new Date().getHours();
  const greetWord = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';
  el.innerHTML = '👋 ' + greetWord + ', ' + currentUser.name.split(' ')[0] + '!';
}

function renderLibStats(){
  const grid = document.getElementById('lib-stats-grid');
  if(!grid) return;
  const totalCopies = BOOKS.reduce((s,b)=>s+b.copies,0);
  const totalAvailable = BOOKS.reduce((s,b)=>s+b.available,0);
  const todayStart = new Date(); todayStart.setHours(0,0,0,0);
  let borrowedToday = 0, overdue = 0;
  getReaderUsers().forEach(u=>{
    (u.history||[]).forEach(h=>{
      if(h.type==='Borrowed' && h.ts >= todayStart.getTime()) borrowedToday++;
    });
    (u.borrowed||[]).forEach(bookId=>{
      const entry = (u.history||[]).find(h=>h.type==='Borrowed' && h.bookId===bookId);
      if(entry && (Date.now() - entry.ts) > 14*86400000) overdue++;
    });
  });
  const cards = [
    {num: BOOKS.length, lbl:'Titles in Catalog'},
    {num: totalCopies, lbl:'Total Copies'},
    {num: totalAvailable, lbl:'Available Now'},
    {num: getReaderUsers().length, lbl:'Registered Members'},
    {num: borrowedToday, lbl:'Borrowed Today'},
    {num: overdue, lbl:'Overdue Items', warn:true}
  ];
  grid.innerHTML = cards.map(c=>`<div class="lib-stat-card${c.warn?' warn':''}"><div class="num">${c.num}</div><div class="lbl">${c.lbl}</div></div>`).join('');
}

function renderLibRequests(){
  const list = document.getElementById('lib-requests-list');
  if(!list) return;
  if(BORROW_REQUESTS.length === 0){
    list.innerHTML = '<div class="empty-state">No pending borrow requests.</div>';
    return;
  }
  list.innerHTML = '';
  BORROW_REQUESTS.forEach(req=>{
    const row = document.createElement('div');
    row.className = 'lib-request-row';
    row.innerHTML = `
      <div class="who">${req.member} <span class="email-tag">${req.email}</span></div>
      <div class="what">requested "${req.book}" — ${req.requested}</div>
      <div class="lib-request-actions">
        <button class="lib-req-btn lib-req-approve">Approve</button>
        <button class="lib-req-btn lib-req-deny">Deny</button>
      </div>`;
    row.querySelector('.lib-req-approve').addEventListener('click', ()=>{
      BORROW_REQUESTS = BORROW_REQUESTS.filter(r=>r.id!==req.id);
      SEED_TRANSACTIONS.unshift({type:'Borrowed', title:req.book, member:req.member, email:req.email, ts:Date.now()});
      toast('Approved ' + req.member + '\'s request for "' + req.book + '".');
      renderLibRequests();
      renderLibTransactions();
    });
    row.querySelector('.lib-req-deny').addEventListener('click', ()=>{
      BORROW_REQUESTS = BORROW_REQUESTS.filter(r=>r.id!==req.id);
      toast('Denied request from ' + req.member + '.');
      renderLibRequests();
    });
    list.appendChild(row);
  });
}

function renderLibBorrowers(){
  const list = document.getElementById('lib-borrowers-list');
  if(!list) return;
  let rows = [];
  getReaderUsers().forEach(u=>{
    (u.borrowed||[]).forEach(bookId=>{
      const book = BOOKS.find(b=>b.id===bookId);
      if(!book) return;
      const entry = (u.history||[]).find(h=>h.type==='Borrowed' && h.bookId===bookId);
      const borrowTs = entry ? entry.ts : Date.now();
      const dueTs = borrowTs + 14*86400000;
      const daysLeft = Math.ceil((dueTs - Date.now()) / 86400000);
      let status;
      if(daysLeft > 1) status = 'Due in ' + daysLeft + ' days';
      else if(daysLeft === 1) status = 'Due Tomorrow';
      else if(daysLeft === 0) status = 'Due Today';
      else status = 'Overdue by ' + Math.abs(daysLeft) + ' days';
      rows.push({name:u.name, email:u.email, title:book.title, status, overdue: daysLeft < 0});
    });
  });
  if(rows.length === 0){
    list.innerHTML = '<div class="empty-state">No members currently have a book checked out.</div>';
    return;
  }
  list.innerHTML = rows.map(r=>`
    <div class="lib-txn-row">
      <div class="what"><b>${r.name}</b> <span class="email-tag">${r.email}</span> — "${r.title}"</div>
      <div class="when" style="${r.overdue?'color:#c94a4a;font-weight:700;':''}">${r.status}</div>
    </div>`).join('');
}

function getAllTransactions(){
  let real = [];
  getReaderUsers().forEach(u=>{
    (u.history||[]).forEach(h=>real.push({type:h.type, title:h.title, member:u.name, email:u.email, ts:h.ts}));
  });
  return [...real, ...SEED_TRANSACTIONS].sort((a,b)=>b.ts-a.ts).slice(0,8);
}

function renderLibTransactions(){
  const list = document.getElementById('lib-transactions-list');
  if(!list) return;
  const txns = getAllTransactions();
  if(txns.length === 0){
    list.innerHTML = '<div class="empty-state">No transactions yet.</div>';
    return;
  }
  list.innerHTML = txns.map(t=>`
    <div class="lib-txn-row">
      <span class="tag ${t.type==='Borrowed'?'borrowed':'returned'}">${t.type}</span>
      <div class="what">${t.title} — ${t.member} <span class="email-tag">${t.email || ''}</span></div>
      <div class="when">${new Date(t.ts).toLocaleString()}</div>
    </div>`).join('');
}

function renderLibInventory(){
  const wrap = document.getElementById('lib-inventory-overview');
  if(!wrap) return;
  let html = '';
  CATEGORIES.forEach(cat=>{
    const inCat = BOOKS.filter(b=>b.category===cat);
    const copies = inCat.reduce((s,b)=>s+b.copies,0);
    const available = inCat.reduce((s,b)=>s+b.available,0);
    const pct = copies ? Math.round((available/copies)*100) : 0;
    html += `<div class="lib-inv-row">
      <div class="lib-inv-label">${cat}</div>
      <div class="lib-inv-bar-track"><div class="lib-inv-bar-fill" style="width:${pct}%;"></div></div>
      <div class="lib-inv-count">${available}/${copies}</div>
    </div>`;
  });
  const lowStock = BOOKS.filter(b=>b.available===0);
  if(lowStock.length){
    html += `<div class="lib-lowstock">⚠ ${lowStock.length} title${lowStock.length>1?'s':''} fully checked out: ${lowStock.map(b=>b.title).join(', ')}</div>`;
  }
  wrap.innerHTML = html;
}

function renderLibReports(){
  const grid = document.getElementById('lib-reports-grid');
  if(!grid) return;
  grid.innerHTML = '';
  REPORTS.forEach(r=>{
    const card = document.createElement('div');
    card.className = 'lib-report-card';
    card.innerHTML = `<h3>${r.title}</h3><p>${r.desc}</p><button>View Report</button>`;
    const button = card.querySelector('button');
    if(button){
      button.addEventListener('click', ()=>openReportModal(r.id));
    }
    grid.appendChild(card);
  });
}

function openReportModal(id){
  const report = REPORTS.find(r=>r.id===id);
  if(!report) return;
  let body = '';
  if(id === 'category'){
    body = CATEGORIES.map(cat=>{
      const inCat = BOOKS.filter(b=>b.category===cat);
      const copies = inCat.reduce((s,b)=>s+b.copies,0);
      const available = inCat.reduce((s,b)=>s+b.available,0);
      return cat + ': ' + available + ' available / ' + copies + ' total';
    }).join('\n');
  } else if(id === 'overdue'){
    let lines = [];
    getReaderUsers().forEach(u=>{
      (u.borrowed||[]).forEach(bookId=>{
        const book = BOOKS.find(b=>b.id===bookId);
        const entry = (u.history||[]).find(h=>h.type==='Borrowed' && h.bookId===bookId);
        if(book && entry && (Date.now()-entry.ts) > 14*86400000){
          lines.push(u.name + ' — "' + book.title + '"');
        }
      });
    });
    body = lines.length ? lines.join('\n') : 'No overdue items right now.';
  } else if(id === 'members'){
    const counts = {};
    getAllTransactions().forEach(t=>{ counts[t.member] = (counts[t.member]||0)+1; });
    body = Object.keys(counts).length
      ? Object.entries(counts).map(([m,c])=>m + ': ' + c + ' transaction' + (c>1?'s':'')).join('\n')
      : 'No member activity recorded yet.';
  } else if(id === 'lowstock'){
    const lowStock = BOOKS.filter(b=>b.available===0);
    body = lowStock.length ? lowStock.map(b=>b.title + ' (' + b.category + ')').join('\n') : 'No titles are fully checked out.';
  }
  const titleEl = document.getElementById('info-title');
  const dateEl = document.getElementById('info-date');
  const bodyEl = document.getElementById('info-body');
  if(titleEl) titleEl.textContent = report.title;
  if(dateEl) dateEl.textContent = 'Generated ' + new Date().toLocaleDateString();
  if(bodyEl){
    bodyEl.style.whiteSpace = 'pre-line';
    bodyEl.textContent = body;
  }
  const overlay = document.getElementById('info-overlay');
  if(overlay) overlay.classList.add('open');
}

function renderLibCalendar(){
  const wrap = document.getElementById('lib-calendar');
  if(!wrap) return;
  const now = new Date();
  const year = now.getFullYear(), month = now.getMonth();
  const monthName = now.toLocaleDateString('en-US', {month:'long', year:'numeric'});
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month+1, 0).getDate();
  const events = {3:'New Book Arrivals', 15:'Library Workshop', [daysInMonth]:'Late Fee Review'};

  let html = `<div class="lib-cal-title">${monthName}</div><div class="lib-cal-grid">`;
  ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(d=>{ html += `<div class="lib-cal-dow">${d}</div>`; });
  for(let i=0;i<firstDay;i++) html += `<div class="lib-cal-day empty"></div>`;
  for(let d=1; d<=daysInMonth; d++){
    const isToday = d === now.getDate();
    const eventName = events[d];
    html += `<div class="lib-cal-day${isToday?' today':''}${eventName?' event':''}" ${eventName?`data-event="${eventName}"`:''}>${d}${eventName?'<span class="dot"></span>':''}</div>`;
  }
  html += `</div>`;
  wrap.innerHTML = html;
  wrap.querySelectorAll('.lib-cal-day.event').forEach(el=>{
    el.addEventListener('click', ()=>toast('📅 ' + el.dataset.event));
  });
}

function renderManageBooks(){
  const wrap = document.getElementById('mb-table');
  if(!wrap) return;

  const select = document.getElementById('nbk-category');
  if(select && select.options.length === 0){
    CATEGORIES.forEach(c=>{
      const o = document.createElement('option');
      o.value = c; o.textContent = c;
      select.appendChild(o);
    });
  }

  const table = document.createElement('table');
  table.className = 'mb-table';
  table.innerHTML = `<thead><tr><th>Cover</th><th>Title</th><th>Author</th><th>Category</th><th>Copies</th><th>Available</th><th>Actions</th></tr></thead>`;
  const tbody = document.createElement('tbody');

  BOOKS.forEach(book=>{
    const tr = document.createElement('tr');
    tr.dataset.bookId = book.id;
    tr.innerHTML = `
      <td><img class="mb-cover-thumb" loading="lazy" alt="${book.title} cover" src="https://covers.openlibrary.org/b/isbn/${encodeURIComponent(book.isbn)}-S.jpg" onerror="this.style.visibility='hidden'"></td>
      <td>${book.title}</td>
      <td>${book.author}</td>
      <td>${book.category}</td>
      <td class="mb-copies-cell">${book.copies}</td>
      <td class="mb-available-cell">${book.available}</td>
      <td class="mb-actions-cell">
        <button class="mb-action-btn mb-edit">Edit</button>
        <button class="mb-action-btn mb-delete">Delete</button>
      </td>`;
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  wrap.innerHTML = '';
  wrap.appendChild(table);

  wrap.querySelectorAll('.mb-edit').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      const tr = e.target.closest('tr');
      const id = Number(tr.dataset.bookId);
      const book = BOOKS.find(b=>b.id===id);
      if(!book) return;
      tr.querySelector('.mb-copies-cell').innerHTML = `<input type="number" min="0" value="${book.copies}" class="mb-copies-input">`;
      tr.querySelector('.mb-available-cell').innerHTML = `<input type="number" min="0" value="${book.available}" class="mb-available-input">`;
      btn.textContent = 'Save';
      btn.classList.remove('mb-edit');
      btn.classList.add('mb-save');
      btn.replaceWith(btn.cloneNode(true));
      const saveBtn = tr.querySelector('.mb-save');
      if(saveBtn){
        saveBtn.addEventListener('click', ()=>{
          const newCopies = parseInt(tr.querySelector('.mb-copies-input').value, 10) || 0;
          let newAvailable = parseInt(tr.querySelector('.mb-available-input').value, 10) || 0;
          if(newAvailable > newCopies) newAvailable = newCopies;
          book.copies = newCopies;
          book.available = newAvailable;
          persistBooks();
          toast('Updated "' + book.title + '".');
          renderManageBooks();
          renderAllBooks();
          renderFeatured();
        });
      }
    });
  });

  wrap.querySelectorAll('.mb-delete').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      const tr = e.target.closest('tr');
      const id = Number(tr.dataset.bookId);
      if(!btn.classList.contains('confirming')){
        btn.classList.add('confirming');
        btn.textContent = 'Confirm?';
        setTimeout(()=>{
          if(btn.classList.contains('confirming')){
            btn.classList.remove('confirming');
            btn.textContent = 'Delete';
          }
        }, 3000);
        return;
      }
      const idx = BOOKS.findIndex(b=>b.id===id);
      if(idx !== -1){
        const removed = BOOKS.splice(idx,1)[0];
        persistBooks();
        toast('Deleted "' + removed.title + '".');
      }
      renderManageBooks();
      renderAllBooks();
      renderFeatured();
      populateCategoryGrid();
    });
  });
}

const libActionAdd = document.getElementById('lib-action-add');
if(libActionAdd){
  libActionAdd.addEventListener('click', ()=>{
    showView('managebooks');
    const form = document.getElementById('mb-add-form');
    if(form) form.style.display = 'block';
  });
}
const libActionManage = document.getElementById('lib-action-manage');
if(libActionManage){
  libActionManage.addEventListener('click', ()=>showView('managebooks'));
}
const libActionReports = document.getElementById('lib-action-reports');
if(libActionReports){
  libActionReports.addEventListener('click', ()=>{
    const section = document.getElementById('lib-reports-section');
    if(section) section.scrollIntoView({behavior:'smooth', block:'start'});
  });
}
const libActionCalendar = document.getElementById('lib-action-calendar');
if(libActionCalendar){
  libActionCalendar.addEventListener('click', ()=>{
    const section = document.getElementById('lib-calendar-section');
    if(section) section.scrollIntoView({behavior:'smooth', block:'start'});
  });
}
const mbAddToggle = document.getElementById('mb-add-toggle');
if(mbAddToggle){
  mbAddToggle.addEventListener('click', ()=>{
    const form = document.getElementById('mb-add-form');
    if(form) form.style.display = form.style.display === 'none' ? 'block' : 'none';
  });
}
const mbCancelNew = document.getElementById('mb-cancel-new');
if(mbCancelNew){
  mbCancelNew.addEventListener('click', ()=>{
    const form = document.getElementById('mb-add-form');
    if(form) form.style.display = 'none';
  });
}
const mbSaveNew = document.getElementById('mb-save-new');
if(mbSaveNew){
  mbSaveNew.addEventListener('click', ()=>{
    const title = document.getElementById('nbk-title').value.trim();
    const author = document.getElementById('nbk-author').value.trim();
    const category = document.getElementById('nbk-category').value;
    const date = document.getElementById('nbk-date').value.trim();
    const publisher = document.getElementById('nbk-publisher').value.trim();
    const isbn = document.getElementById('nbk-isbn').value.trim();
    const copies = parseInt(document.getElementById('nbk-copies').value, 10) || 1;
    const msg = document.getElementById('mb-msg');
    if(!title || !author || !category || !date || !publisher || !isbn){
      if(msg){ msg.className = 'msg err'; msg.textContent = 'Please fill in every field.'; }
      return;
    }
    const newId = BOOKS.length ? Math.max(...BOOKS.map(b=>b.id)) + 1 : 1;
    BOOKS.push({
      id:newId,
      title: escapeHtml(title),
      author: escapeHtml(author),
      category,
      date: escapeHtml(date),
      publisher: escapeHtml(publisher),
      isbn: escapeHtml(isbn),
      copies,
      available:copies
    });
    persistBooks();
    if(msg){ msg.textContent = ''; }
    ['nbk-title','nbk-author','nbk-date','nbk-publisher','nbk-isbn'].forEach(id=>{
      const el = document.getElementById(id);
      if(el) el.value = '';
    });
    const copiesEl = document.getElementById('nbk-copies');
    if(copiesEl) copiesEl.value = 1;
    const form = document.getElementById('mb-add-form');
    if(form) form.style.display = 'none';
    toast('Added "' + title + '" to the catalog.');
    renderManageBooks();
    renderAllBooks();
    renderFeatured();
    populateCategoryGrid();
  });
}
