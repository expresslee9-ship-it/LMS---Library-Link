async function loadHistory(){

const {

data:{session}

}=await supabaseClient.auth.getSession();

const table=document.getElementById("historyTable");

const {data,error}=await supabaseClient

.from("borrow_records")

.select(`
borrow_date,
return_date,
status,
books(title)
`)

.eq("user_id",session.user.id);

table.innerHTML="";

data.forEach(item=>{

table.innerHTML+=`

<tr>

<td>${item.books.title}</td>

<td>${item.status}</td>

<td>${item.borrow_date}</td>

<td>${item.return_date || "-"}</td>

</tr>

`;

});

}

loadHistory();