/* ===================== ANNOUNCEMENTS ===================== */
function renderAnnouncements(){
  ['ann-pills','ann-pills-public','ann-pills-lib'].forEach(containerId=>{
    const wrap = document.getElementById(containerId);
    if(!wrap) return;
    wrap.innerHTML = '';
    if(annTimers[containerId]) clearInterval(annTimers[containerId]);

    const slideshow = document.createElement('div');
    slideshow.className = 'ann-slideshow';
    ANNOUNCEMENTS.forEach((a, i)=>{
      const slide = document.createElement('div');
      slide.className = 'ann-slide' + (i === 0 ? ' active' : '');
      slide.innerHTML = `<div class="icon">${a.icon}</div><h3>${a.title}</h3><p>${a.body}</p><div class="tap-hint">Tap to read more</div>`;
      slide.addEventListener('click', ()=>openInfoModal(a.id));
      slideshow.appendChild(slide);
    });
    wrap.appendChild(slideshow);

    const dots = document.createElement('div');
    dots.className = 'ann-dots';
    ANNOUNCEMENTS.forEach((a, i)=>{
      const dot = document.createElement('button');
      dot.className = 'ann-dot' + (i === 0 ? ' active' : '');
      dot.addEventListener('click', (e)=>{
        e.stopPropagation();
        goToAnnSlide(wrap, i);
        restartAnnTimer(containerId, wrap);
      });
      dots.appendChild(dot);
    });
    wrap.appendChild(dots);

    restartAnnTimer(containerId, wrap);
    slideshow.addEventListener('mouseenter', ()=>clearInterval(annTimers[containerId]));
    slideshow.addEventListener('mouseleave', ()=>restartAnnTimer(containerId, wrap));
  });
}

function goToAnnSlide(wrap, index){
  wrap.querySelectorAll('.ann-slide').forEach((s,i)=>s.classList.toggle('active', i===index));
  wrap.querySelectorAll('.ann-dot').forEach((d,i)=>d.classList.toggle('active', i===index));
}

function restartAnnTimer(containerId, wrap){
  clearInterval(annTimers[containerId]);
  annTimers[containerId] = setInterval(()=>{
    const dots = wrap.querySelectorAll('.ann-dot');
    let current = 0;
    dots.forEach((d,i)=>{ if(d.classList.contains('active')) current = i; });
    goToAnnSlide(wrap, (current + 1) % ANNOUNCEMENTS.length);
  }, 4000);
}

function openInfoModal(id){
  const a = ANNOUNCEMENTS.find(x=>x.id===id);
  if(!a) return;
  const titleEl = document.getElementById('info-title');
  const dateEl = document.getElementById('info-date');
  const bodyEl = document.getElementById('info-body');
  if(titleEl) titleEl.textContent = a.title;
  if(dateEl) dateEl.textContent = a.date;
  if(bodyEl) bodyEl.textContent = a.body;
  const overlay = document.getElementById('info-overlay');
  if(overlay) overlay.classList.add('open');
}

const infoClose = document.getElementById('info-close');
if(infoClose) infoClose.addEventListener('click', ()=>{
  const overlay = document.getElementById('info-overlay');
  if(overlay) overlay.classList.remove('open');
});

const infoOverlay = document.getElementById('info-overlay');
if(infoOverlay){
  infoOverlay.addEventListener('click', (e)=>{
    if(e.target.id === 'info-overlay') infoOverlay.classList.remove('open');
  });
}
