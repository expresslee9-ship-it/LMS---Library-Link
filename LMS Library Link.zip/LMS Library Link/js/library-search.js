/* ===================== LIVE SEARCH SUGGESTIONS ===================== */
function renderSearchSuggestions(query, dropdownEl, categoryElId){
  const q = query.trim().toLowerCase();
  if(!q){
    dropdownEl.classList.remove('open');
    dropdownEl.innerHTML = '';
    return;
  }

  const matches = BOOKS.filter(b =>
    b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q) || b.category.toLowerCase().includes(q)
  );

  dropdownEl.innerHTML = '';
  if(matches.length === 0){
    dropdownEl.innerHTML = '<div class="sr-empty">No books match "' + escapeHtml(query.trim()) + '".</div>';
    dropdownEl.classList.add('open');
    return;
  }

  matches.slice(0,6).forEach(book=>{
    const row = document.createElement('div');
    row.className = 'sr-item';
    const swatch = document.createElement('div');
    swatch.className = 'sr-swatch';
    swatch.style.background = COVER_COLORS[book.category] || 'var(--brown)';
    const info = document.createElement('div');
    info.className = 'sr-info';
    info.innerHTML = `<div class="sr-title">${book.title}</div><div class="sr-author">${book.author} · ${book.category}</div>`;
    const badge = document.createElement('div');
    badge.className = 'sr-avail ' + (book.available>0 ? 'yes' : 'no');
    badge.textContent = book.available>0 ? 'Available' : 'Borrowed';
    row.appendChild(swatch); row.appendChild(info); row.appendChild(badge);
    row.addEventListener('click', ()=>{
      dropdownEl.classList.remove('open');
      openModal(book.id);
    });
    dropdownEl.appendChild(row);
  });

  if(matches.length > 6){
    const more = document.createElement('div');
    more.className = 'sr-more';
    more.textContent = 'See all ' + matches.length + ' results';
    more.addEventListener('click', ()=>{
      dropdownEl.classList.remove('open');
      const cat = categoryElId ? document.getElementById(categoryElId).value : '';
      goToBooksWithFilters(query, cat);
    });
    dropdownEl.appendChild(more);
  }

  dropdownEl.classList.add('open');
}

function initSearchBar(inputId, resultsId, categoryId){
  const input = document.getElementById(inputId);
  const results = document.getElementById(resultsId);
  if(!input || !results) return;

  input.addEventListener('input', ()=>{
    renderSearchSuggestions(input.value, results, categoryId);
  });
  input.addEventListener('focus', ()=>{
    if(input.value.trim()) renderSearchSuggestions(input.value, results, categoryId);
  });
  input.addEventListener('keydown', (e)=>{
    if(e.key === 'Escape'){ results.classList.remove('open'); input.blur(); }
    if(e.key === 'Enter'){
      results.classList.remove('open');
      const cat = categoryId ? document.getElementById(categoryId).value : '';
      goToBooksWithFilters(input.value, cat);
    }
  });

  const categoryEl = categoryId ? document.getElementById(categoryId) : null;
  if(categoryEl){
    categoryEl.addEventListener('change', (e)=>{
      results.classList.remove('open');
      goToBooksWithFilters(input.value, e.target.value);
    });
  }
}

document.addEventListener('click', (e)=>{
  document.querySelectorAll('.search-results.open').forEach(dd=>{
    const wrap = dd.closest('.search-bar-wrap');
    if(wrap && !wrap.contains(e.target)) dd.classList.remove('open');
  });
});

function goToBooksWithFilters(query, cat){
  const booksSearch = document.getElementById('books-search');
  const booksCategory = document.getElementById('books-category');
  if(booksSearch) booksSearch.value = query || '';
  if(booksCategory) booksCategory.value = cat || '';
  showView('books');
  renderAllBooks();
}

const ctaBrowse = document.getElementById('cta-browse');
if(ctaBrowse) ctaBrowse.addEventListener('click', ()=>goToBooksWithFilters('',''));
const ctaViewMore = document.getElementById('cta-view-more');
if(ctaViewMore) ctaViewMore.addEventListener('click', ()=>goToBooksWithFilters('',''));
const memberBrowseBtn = document.getElementById('member-browse-btn');
if(memberBrowseBtn) memberBrowseBtn.addEventListener('click', ()=>goToBooksWithFilters('',''));
const memberBorrowBtn = document.getElementById('member-borrow-btn');
if(memberBorrowBtn) memberBorrowBtn.addEventListener('click', ()=>goToBooksWithFilters('',''));
const memberHistoryBtn = document.getElementById('member-history-btn');
if(memberHistoryBtn) memberHistoryBtn.addEventListener('click', ()=>showView('history'));
const ctaViewAllActivity = document.getElementById('cta-view-all-activity');
if(ctaViewAllActivity) ctaViewAllActivity.addEventListener('click', ()=>showView('history'));
const ctaGetStarted = document.getElementById('cta-get-started');
if(ctaGetStarted) ctaGetStarted.addEventListener('click', ()=>{
  showView(currentUser ? 'books' : 'role');
});
