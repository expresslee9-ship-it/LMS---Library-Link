// ===============================
// Library Link Dashboard
// ===============================

let currentUserId = null;

function ensureSupabaseClient() {
    if (typeof supabaseClient === 'undefined' || !supabaseClient) {
        console.error('supabaseClient is not initialized.');
        const t = document.getElementById('toast');
        if (t) {
            t.textContent = 'Database connection not ready.';
            t.classList.add('show');
            setTimeout(() => t.classList.remove('show'), 2400);
        }
        return false;
    }
    return true;
}

async function checkSession() {
    if (!ensureSupabaseClient()) return;

    const { data: { session } } = await supabaseClient.auth.getSession();

    if (!session) {
        window.location.href = 'login.html';
        return;
    }

    currentUserId = session.user?.id || null;
    loadUser(session.user);
    await loadDashboard();
}

checkSession();

function loadUser(user) {
    const el = document.getElementById('studentName');
    if (!el) return;
    el.textContent = user?.user_metadata?.fullname || user?.email || '';
}

async function logout() {
    if (!ensureSupabaseClient()) return;
    await supabaseClient.auth.signOut();
    window.location.href = 'login.html';
}

function formatDate(dateLike) {
    if (!dateLike) return '-';
    const d = new Date(dateLike);
    if (Number.isNaN(d.getTime())) return String(dateLike);
    return d.toLocaleDateString();
}

function escapeHtml(str) {
    return String(str ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '<')
        .replaceAll('>', '>')
        .replaceAll('"', '"')
        .replaceAll("'", '&#039;');
}

async function loadDashboard() {
    await Promise.all([
        loadBorrowedBooks(),
        loadAvailableBooks(),
        loadNotifications(),
        loadDueBooks(),
        loadReservations()
    ]);
}

async function loadBorrowedBooks() {
    const table = document.getElementById('borrowTable');
    if (!table) return;

    table.innerHTML = '';

    const { data, error } = await supabaseClient
        .from('borrow_records')
        .select('borrow_date,due_date,status,books(title)')
        .eq('user_id', currentUserId);

    if (error) {
        console.log(error);
        table.innerHTML = '<tr><td colspan="4">Unable to load books.</td></tr>';
        return;
    }

    if (!data || data.length === 0) {
        table.innerHTML = '<tr><td colspan="4">No borrowed books.</td></tr>';
        const countEl = document.getElementById('borrowedCount');
        if (countEl) countEl.innerHTML = 0;
        return;
    }

    const countEl = document.getElementById('borrowedCount');
    if (countEl) countEl.innerHTML = data.length;

    data.forEach(record => {
        const title = record?.books?.title || '(Unknown book)';
        table.innerHTML += `
            <tr>
                <td>${escapeHtml(title)}</td>
                <td>${formatDate(record.borrow_date)}</td>
                <td>${formatDate(record.due_date)}</td>
                <td>${escapeHtml(record.status || '-')}</td>
            </tr>
        `;
    });
}

async function loadNotifications() {
    const el = document.getElementById('notificationCount');
    if (!el) return;

    const { data, error } = await supabaseClient
        .from('notifications')
        .select('id')
        .eq('user_id', currentUserId);

    if (error) {
        console.log(error);
        return;
    }

    el.innerHTML = data ? data.length : 0;
}

async function loadAvailableBooks() {
    const grid = document.querySelector('.book-grid');
    if (!grid) return;

    const { data, error } = await supabaseClient
        .from('books')
        .select('id,title,author,category,isbn')
        .order('id', { ascending: false })
        .limit(4);

    if (error) {
        console.log(error);
        return;
    }

    grid.innerHTML = '';

    const books = data || [];
    if (books.length === 0) {
        grid.innerHTML = '<div class="book-empty">No recently added books.</div>';
        return;
    }

    books.forEach(book => {
        const title = escapeHtml(book.title || '');
        const author = book.author ? escapeHtml(book.author) : null;

        const isbn = book.isbn ? encodeURIComponent(book.isbn) : null;
        const imgSrc = isbn
            ? `https://covers.openlibrary.org/b/isbn/${isbn}-M.jpg`
            : `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(
                `<svg xmlns="http://www.w3.org/2000/svg" width="220" height="300"><rect width="220" height="300" fill="#ddd"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="Arial" font-size="18" fill="#666">${title || 'Book'}</text></svg>`
            )}`;

        grid.innerHTML += `
            <div class="book">
                <img src="${imgSrc}" alt="${title}" />
                <h4>${title}</h4>
                ${author ? `<p class="book-author">${author}</p>` : ''}
                <button type="button" class="borrow-btn" data-book-id="${escapeHtml(book.id)}">Borrow</button>
            </div>
        `;
    });
}

async function loadDueBooks() {
    const el = document.getElementById('dueCount');
    if (!el) return;

    const { data, error } = await supabaseClient
        .from('borrow_records')
        .select('id')
        .eq('status', 'Borrowed')
        .eq('user_id', currentUserId);

    if (error) {
        console.log(error);
        return;
    }

    el.innerHTML = data ? data.length : 0;
}

async function loadReservations() {
    const el = document.getElementById('reserveCount');
    if (!el) return;

    const { data, error } = await supabaseClient
        .from('reservations')
        .select('id')
        .eq('user_id', currentUserId);

    if (error) {
        console.log(error);
        return;
    }

    el.innerHTML = data ? data.length : 0;
}

// Event delegation for dashboard "Borrow" buttons
(function attachBorrowHandler() {
    document.addEventListener('click', async (e) => {
        const btn = e.target && e.target.closest ? e.target.closest('.borrow-btn') : null;
        if (!btn) return;

        const bookId = btn.getAttribute('data-book-id');
        if (!bookId) return;

        // Fallback behavior: redirect to borrow flow.
        // If borrow.html supports query params, use them; otherwise it will still load.
        window.location.href = `borrow.html?bookId=${encodeURIComponent(bookId)}`;
    });
})();

const hour = new Date().getHours();
const headerTitle = document.querySelector('header h1');
if (headerTitle) {
    if (hour < 12) headerTitle.innerHTML = 'Good Morning!';
    else if (hour < 18) headerTitle.innerHTML = 'Good Afternoon!';
    else headerTitle.innerHTML = 'Good Evening!';
}

