/* Minimal Supabase compatibility shim for offline use */
(function(){
  if(typeof window.supabase !== 'undefined' && typeof window.supabaseClient !== 'undefined') return;

  const stub = {
    createClient: function(){ return stub; },
    auth: {
      getSession: async function(){ return { data:{ session:null }, error:null }; },
      signInWithPassword: async function(){ return { data:null, error:{ message:'Supabase unavailable' } }; },
      signUp: async function(){ return { data:null, error:{ message:'Supabase unavailable' } }; },
      signOut: async function(){ return { error:null }; },
      resetPasswordForEmail: async function(){ return { error:null }; },
      signInWithOAuth: async function(){ return { error:{ message:'Supabase unavailable' } }; }
    },
    from: function(){
      return {
        select: async function(){ return { data:[], error:null }; },
        eq: function(){ return this; },
        update: async function(){ return { data:null, error:null }; },
        insert: async function(){ return { data:null, error:null }; }
      };
    }
  };

  window.supabase = stub;
  window.supabaseClient = stub;
})();