// =========================
// Library Link Authentication
// =========================

// Show / Hide Password
const togglePassword = document.getElementById("togglePassword");

if (togglePassword) {

    togglePassword.addEventListener("click", () => {

        const password = document.getElementById("password");

        const icon = togglePassword.querySelector(".material-icons");

        if (password.type === "password") {

            password.type = "text";
            icon.textContent = "visibility_off";

        } else {

            password.type = "password";
            icon.textContent = "visibility";

        }

    });

}


// =========================
// LOGIN
// =========================

const loginForm = document.getElementById("loginForm");

if (loginForm) {

loginForm.addEventListener("submit", async (e) => {

e.preventDefault();

const email = document.getElementById("email").value.trim();

const password = document.getElementById("password").value;

const remember = document.getElementById("remember").checked;

const message = document.getElementById("message");

message.innerHTML = "Signing in...";

const { data, error } = await supabaseClient.auth.signInWithPassword({

email,
password

});

if (error) {

message.style.color = "red";
message.innerHTML = error.message;

return;

}

if (remember) {

localStorage.setItem("rememberUser", "true");

} else {

localStorage.removeItem("rememberUser");

}

message.style.color = "green";

message.innerHTML = "Login Successful!";

setTimeout(() => {

window.location.href = "dashboard.html";

},1000);

});

}



// =========================
// GOOGLE LOGIN
// =========================

const googleLogin = document.getElementById("googleLogin");

if (googleLogin) {

googleLogin.addEventListener("click", async () => {

await supabaseClient.auth.signInWithOAuth({

provider: "google",

options: {

redirectTo: window.location.origin + "/dashboard.html"

}

});

});

}



// =========================
// REGISTER
// =========================

const registerForm = document.getElementById("registerForm");

if (registerForm) {

registerForm.addEventListener("submit", async(e)=>{

e.preventDefault();

const fullname=document.getElementById("fullname").value;

const studentid=document.getElementById("studentid").value;

const email=document.getElementById("email").value;

const password=document.getElementById("password").value;

const confirm=document.getElementById("confirmPassword").value;

const message=document.getElementById("message");

if(password!==confirm){

message.style.color="red";

message.innerHTML="Passwords do not match.";

return;

}

const {data,error}=await supabaseClient.auth.signUp({

email,

password,

options:{

data:{

fullname,

studentid

}

}

});

if(error){

message.style.color="red";

message.innerHTML=error.message;

return;

}

message.style.color="green";

message.innerHTML="Registration successful! Check your email.";

});

}



// =========================
// GOOGLE REGISTER
// =========================

const googleRegister=document.getElementById("googleRegister");

if(googleRegister){

googleRegister.addEventListener("click",async()=>{

await supabaseClient.auth.signInWithOAuth({

provider:"google",

options:{

redirectTo:window.location.origin+"/dashboard.html"

}

});

});

}



// =========================
// FORGOT PASSWORD
// =========================

const forgotForm=document.getElementById("forgotForm");

if(forgotForm){

forgotForm.addEventListener("submit",async(e)=>{

e.preventDefault();

const email=document.getElementById("email").value;

const message=document.getElementById("message");

const {error}=await supabaseClient.auth.resetPasswordForEmail(

email,

{

redirectTo:window.location.origin+"/reset-password.html"

}

);

if(error){

message.style.color="red";

message.innerHTML=error.message;

return;

}

message.style.color="green";

message.innerHTML="Password reset email sent.";

});

}



// =========================
// CHECK SESSION
// =========================

async function checkUser(){

const{

data:{session}

}=await supabaseClient.auth.getSession();

if(session){

console.log("Logged In");

}

}

checkUser();



// =========================
// LOGOUT
// =========================

async function logout(){

await supabaseClient.auth.signOut();

window.location.href="login.html";

}